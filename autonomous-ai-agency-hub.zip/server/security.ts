import { Request, Response, NextFunction } from "express";
import crypto from "crypto";

// --- Types ---
export interface User {
  id: string;
  email: string;
  passwordHash: string; // pbkdf2:100000:sha256:salt:hash
  isVerified: boolean;
  verificationCode?: string;
  verificationCodeExpiresAt?: number;
  resetToken?: string;
  resetTokenExpiresAt?: number;
}

export interface Session {
  id: string;
  userId: string;
  email: string;
  createdAt: number;
  expiresAt: number;
}

// --- Shared Database In-Memory (Secure Single-Tenant/Multi-Tenant Context) ---
// Pre-populate with a secure default user as requested or dynamically created.
// Default credentials (Email: user's email if available, otherwise anasshaik167@gmail.com)
export const mockUsers: Record<string, User> = {};

// Sessions store
export const activeSessions = new Map<string, Session>();

// Rate Limiting Stores
// Maps IP or Email -> list of timestamp attempts
const loginAttempts = new Map<string, number[]>();
const resetAttempts = new Map<string, number[]>();

// --- Cryptographic Passwords Helper ---
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(32).toString("hex");
  const iterations = 100000;
  const hash = crypto.pbkdf2Sync(password, salt, iterations, 64, "sha256").toString("hex");
  return `pbkdf2:${iterations}:sha256:${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const parts = storedHash.split(":");
    if (parts.length !== 5 || parts[0] !== "pbkdf2") return false;
    const iterations = parseInt(parts[1], 10);
    const salt = parts[3];
    const originalHash = parts[4];
    
    const hash = crypto.pbkdf2Sync(password, salt, iterations, 64, "sha256").toString("hex");
    return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(originalHash, "hex"));
  } catch (err) {
    return false;
  }
}

// --- Generate Secure Token ---
export function generateSecureToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

// Generates a 6-digit numeric verification code
export function generateVerificationCode(): string {
  return crypto.randomInt(100000, 999999).toString();
}

// --- Initialize Default User ---
export function initializeUser(email: string) {
  const normalizedEmail = email.toLowerCase().trim();
  if (!mockUsers[normalizedEmail]) {
    // Default master password "SecurePassword123!" pre-configured
    mockUsers[normalizedEmail] = {
      id: "usr_" + crypto.randomBytes(8).toString("hex"),
      email: normalizedEmail,
      passwordHash: hashPassword("SecurePassword123!"),
      isVerified: true // Pre-verified master user
    };
    console.log(`[Security] Secure user seed initialized: ${normalizedEmail} / SecurePassword123!`);
  }
}

// --- Rate Limiting Middleware ---
export function rateLimitLogin(req: Request, res: Response, next: NextFunction) {
  const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress || "127.0.0.1";
  const now = Date.now();
  const windowMs = 5 * 60 * 1000; // 5 minutes window
  const maxAttempts = 5;

  let attempts = loginAttempts.get(ip) || [];
  // Filter attempts in window
  attempts = attempts.filter(ts => now - ts < windowMs);
  attempts.push(now);
  loginAttempts.set(ip, attempts);

  if (attempts.length > maxAttempts) {
    return res.status(429).json({
      error: "BRUTE_FORCE_DETECTED",
      message: "Security Lockout: Too many login attempts. Please try again in 5 minutes."
    });
  }
  next();
}

export function rateLimitReset(req: Request, res: Response, next: NextFunction) {
  const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress || "127.0.0.1";
  const now = Date.now();
  const windowMs = 15 * 60 * 1000; // 15 minutes window
  const maxAttempts = 3;

  let attempts = resetAttempts.get(ip) || [];
  attempts = attempts.filter(ts => now - ts < windowMs);
  attempts.push(now);
  resetAttempts.set(ip, attempts);

  if (attempts.length > maxAttempts) {
    return res.status(429).json({
      error: "RATE_LIMIT_EXCEEDED",
      message: "Too many password resets. Please wait 15 minutes before requesting again."
    });
  }
  next();
}

// --- Robust Input Validation & Sanitization ---
export function sanitizeInput(val: any): any {
  if (typeof val === "string") {
    // 1. Scrub script tags/HTML injections to prevent SQL / script injection vectors
    let scrubbed = val
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/javascript:/gi, "")
      .replace(/on\w+\s*=/gi, "");
    
    // 2. Escape HTML special structures (prevent DOM XSS)
    scrubbed = scrubbed
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#x27;")
      .replace(/\//g, "&#x2F;");

    return scrubbed.trim();
  } else if (Array.isArray(val)) {
    return val.map(item => sanitizeInput(item));
  } else if (typeof val === "object" && val !== null) {
    const output: Record<string, any> = {};
    for (const key in val) {
      if (Object.prototype.hasOwnProperty.call(val, key)) {
        output[key] = sanitizeInput(val[key]);
      }
    }
    return output;
  }
  return val;
}

// Request Data Validation and Sanitization Middleware
export function validateAndSanitize(req: Request, res: Response, next: NextFunction) {
  // Sanitize body, query params, and parameter tokens
  if (req.body) {
    req.body = sanitizeInput(req.body);
  }
  if (req.query) {
    req.query = sanitizeInput(req.query);
  }
  if (req.params) {
    req.params = sanitizeInput(req.params);
  }
  next();
}

// --- Session Store Operations ---
const SESSION_TTL_MS = 15 * 60 * 1000; // Strict 15-minute authentication window

export function createSession(userId: string, email: string): Session {
  const sessionId = "sess_" + crypto.randomBytes(32).toString("hex");
  const now = Date.now();
  const session: Session = {
    id: sessionId,
    userId,
    email: email.toLowerCase().trim(),
    createdAt: now,
    expiresAt: now + SESSION_TTL_MS
  };
  activeSessions.set(sessionId, session);
  return session;
}

export function validateSession(sessionId: string): Session | null {
  const session = activeSessions.get(sessionId);
  if (!session) return null;

  const now = Date.now();
  if (now > session.expiresAt) {
    activeSessions.delete(sessionId);
    return null;
  }

  // Sliding expiry renewal verification
  // If session is used within the last 5 minutes of expiration, renew session life
  if (session.expiresAt - now < 5 * 60 * 1000) {
    session.expiresAt = now + SESSION_TTL_MS;
    activeSessions.set(sessionId, session);
  }

  return session;
}

// --- Authentication Express Middleware ---
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  // Bypassed: System is fully single-tenant. Automatically grant operator authority.
  (req as any).user = {
    id: "usr_sandbox",
    email: "anasshaik167@gmail.com"
  };
  next();
}

// Expiry garbage collection - runs every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [sid, session] of activeSessions.entries()) {
    if (now > session.expiresAt) {
      activeSessions.delete(sid);
    }
  }
}, 5 * 60 * 1000);
