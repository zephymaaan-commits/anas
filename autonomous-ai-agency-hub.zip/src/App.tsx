import React, { useState, useEffect } from 'react';
import { initialOpportunities, initialLeads, initialCampaigns, initialAppointments, initialTransactions, initialTasks } from './data';
import { Lead, IndustryOpportunity, OutboundCampaign, OBDAppointment, FinancialTransaction, ProjectTask, AIAudit } from './types';
import DashboardStats from './components/DashboardStats';
import MarketIntel from './components/MarketIntel';
import LeadsCRM from './components/LeadsCRM';
import AuditDetails from './components/AuditDetails';
import OutreachFactory from './components/OutreachFactory';
import OutboundPulse from './components/OutboundPulse';
import CalendarInbound from './components/CalendarInbound';
import ProposalRoom from './components/ProposalRoom';
import FinancialLedger from './components/FinancialLedger';
import ServiceDelivery from './components/ServiceDelivery';
import RealWorldActivation from './components/RealWorldActivation';
import AutonomousAutomator from './components/AutonomousAutomator';

import { secureFetch } from './lib/api';

import {
  Sparkles,
  Target,
  Users,
  Search,
  Activity,
  Send,
  Calendar,
  FileText,
  CreditCard,
  CheckCircle,
  Briefcase,
  HelpCircle,
  Shield,
  Loader2,
  Lock,
  Compass
} from 'lucide-react';

export default function App() {
  // Tab Management
  type TabId = 'intel' | 'crm' | 'audits' | 'outreach' | 'campaigns' | 'qualifier' | 'proposals' | 'billing' | 'delivery' | 'activation';
  const [activeTab, setActiveTab] = useState<TabId>('intel');

  // Shared Centralized State Management
  const [leads, setLeads] = useState<Lead[]>(initialLeads);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(initialLeads[0] || null);
  const [opportunities, setOpportunities] = useState<IndustryOpportunity[]>(initialOpportunities);
  const [campaigns, setCampaigns] = useState<OutboundCampaign[]>(initialCampaigns);
  const [appointments, setAppointments] = useState<OBDAppointment[]>(initialAppointments);
  const [transactions, setTransactions] = useState<FinancialTransaction[]>(initialTransactions);
  const [tasks, setTasks] = useState<ProjectTask[]>(initialTasks);

  // Authentication & Clearance Session State (Simplified under a single-operator bypass model)
  const [session] = useState<{ sessionId: string; user: { id: string; email: string } }>({
    sessionId: 'sandbox_session',
    user: { id: 'usr_sandbox', email: 'anasshaik167@gmail.com' }
  });

  // Gmail Live OAuth Integration states
  const [gmailToken, setGmailToken] = useState<string | null>(localStorage.getItem('axon_gmail_token'));
  const [gmailProfile, setGmailProfile] = useState<{ email?: string; name?: string; picture?: string } | null>(
    localStorage.getItem('axon_gmail_profile') ? JSON.parse(localStorage.getItem('axon_gmail_profile')!) : null
  );

  const handleDisconnectGmail = () => {
    localStorage.removeItem('axon_gmail_token');
    localStorage.removeItem('axon_gmail_profile');
    setGmailToken(null);
    setGmailProfile(null);
  };

  const handleConnectGmail = (token: string, profile: { email?: string; name?: string; picture?: string }) => {
    localStorage.setItem('axon_gmail_token', token);
    setGmailToken(token);
    localStorage.setItem('axon_gmail_profile', JSON.stringify(profile));
    setGmailProfile(profile);
  };

  // Google OAuth URL Hash Parser & Popup Interceptor
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const params = new URLSearchParams(hash.substring(1));
      const accessToken = params.get('access_token');
      
      if (accessToken) {
        if (window.opener && window.name === 'Google Sign-In') {
          window.opener.postMessage({ type: 'GMAIL_TOKEN', token: accessToken }, window.location.origin);
          window.close();
          return;
        }

        localStorage.setItem('axon_gmail_token', accessToken);
        setGmailToken(accessToken);
        window.history.replaceState('', document.title, window.location.pathname + window.location.search);

        fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
          headers: { Authorization: `Bearer ${accessToken}` }
        })
        .then(r => r.json())
        .then(profile => {
          const profData = {
            email: profile.email,
            name: profile.name,
            picture: profile.picture
          };
          localStorage.setItem('axon_gmail_profile', JSON.stringify(profData));
          setGmailProfile(profData);
        })
        .catch(err => console.error('Error fetching user info', err));
      }
    }

    const handleMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      if (event.data && event.data.type === 'GMAIL_TOKEN' && event.data.token) {
        const token = event.data.token;
        localStorage.setItem('axon_gmail_token', token);
        setGmailToken(token);
        
        fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
          headers: { Authorization: `Bearer ${token}` }
        })
        .then(r => r.json())
        .then(profile => {
          const profData = {
            email: profile.email,
            name: profile.name,
            picture: profile.picture
          };
          localStorage.setItem('axon_gmail_profile', JSON.stringify(profData));
          setGmailProfile(profData);
        })
        .catch(err => console.error('Error fetching user info', err));
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  // API configuration and telemetry status
  const [apiStatus, setApiStatus] = useState({ configured: false, message: 'Detecting...' });

  // 1. Telemetry Status Sync on load
  useEffect(() => {
    secureFetch('/api/agency/status')
      .then(res => res.json())
      .then(data => {
        setApiStatus({
          configured: data.configured,
          message: data.message
        });
      })
      .catch(() => {
        setApiStatus({
          configured: false,
          message: 'Telemetry inactive. Operating in sandbox mode.'
        });
      });
  }, []);

  // Update a Lead's Status
  const handleUpdateStatus = (leadId: string, status: Lead['status']) => {
    setLeads(prevLeads =>
      prevLeads.map(l => (l.id === leadId ? { ...l, status } : l))
    );
    if (selectedLead?.id === leadId) {
      setSelectedLead(prev => prev ? { ...prev, status } : null);
    }
  };

  // Add custom discovered opportunities (Phase 1)
  const handleAddOpportunities = (newOpps: IndustryOpportunity[]) => {
    setOpportunities(prev => {
      // Avoid duplicate industries
      const currentNames = prev.map(o => o.industry);
      const filteredNew = newOpps.filter(o => !currentNames.includes(o.industry));
      return [...filteredNew, ...prev];
    });
  };

  // Add custom manual lead logs (Phase 2)
  const handleAddLead = (newLead: Lead) => {
    setLeads(prev => [newLead, ...prev]);
    setSelectedLead(newLead);
  };

  // Delete a lead (CRM operation)
  const handleDeleteLead = (leadId: string) => {
    setLeads(prev => prev.filter(l => l.id !== leadId));
    if (selectedLead?.id === leadId) {
      setSelectedLead(null);
    }
  };

  // Add custom generated AI Audit to a Lead (Phase 3)
  const handleUpdateLeadAudit = (leadId: string, audit: AIAudit) => {
    setLeads(prevLeads =>
      prevLeads.map(l => l.id === leadId ? { ...l, audit, status: 'Audited' as const } : l)
    );
    if (selectedLead?.id === leadId) {
      setSelectedLead(prev => prev ? { ...prev, audit, status: 'Audited' as const } : null);
    }
  };

  // Settle Outstanding Pending Invoice Deposits (Phase 9)
  const handleSettleInvoice = (txId: string) => {
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;

    setTransactions(prev =>
      prev.map(t => (t.id === txId ? { ...t, status: 'Paid' as const } : t))
    );
    
    // Auto-promote lead/client to Closed Won status once upfront deposit is paid
    if (tx.isUpfrontPayment) {
      handleUpdateStatus(tx.leadId, 'Closed Won');
    }
  };

  // Automatically record pending invoice transaction
  const handleRecordMobilizationTransaction = (leadId: string, amount: number, desc: string, method: 'Stripe' | 'Wise' | 'PayPal') => {
    const matchedLead = leads.find(l => l.id === leadId);
    const newTx: FinancialTransaction = {
      id: "tx_" + Date.now() + "_" + Math.random().toString(36).substring(2, 9),
      leadId,
      businessName: matchedLead?.businessName ?? "Direct Client",
      amount,
      description: desc,
      method,
      status: 'Pending',
      date: new Date().toISOString().split('T')[0],
      isUpfrontPayment: true
    };
    setTransactions(prev => [newTx, ...prev]);
  };

  const handleAddTransaction = (newTx: FinancialTransaction) => {
    setTransactions(prev => [newTx, ...prev]);
  };

  // Add custom task (Phase 10)
  const handleAddTask = (newTask: ProjectTask) => {
    setTasks(prev => [...prev, newTask]);
  };

  // Checkbox complete task delivery (Phase 10)
  const handleToggleTask = (taskId: string) => {
    setTasks(prev =>
      prev.map(t => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
  };

  // Add custom calendar appt
  const handleAddAppointment = (appt: OBDAppointment) => {
    setAppointments(prev => [appt, ...prev]);
    handleUpdateStatus(appt.leadId, 'Meeting Booked');
  };

  // Outreach simulation statistic boosters
  const handleIncrementOutboundStats = () => {
    setCampaigns(prev =>
      prev.map(c => {
        if (c.status === 'Active') {
          const incSent = Math.floor(Math.random() * 5) + 2;
          const incOpens = Math.floor(incSent * 0.7);
          const incReplies = Math.floor(incSent * 0.15);
          return {
            ...c,
            sent: c.sent + incSent,
            opens: c.opens + incOpens,
            replies: c.replies + incReplies
          };
        }
        return c;
      })
    );
  };

  const handleToggleCampaignStatus = (campId: string) => {
    setCampaigns(prev =>
      prev.map(c => (c.id === campId ? { ...c, status: c.status === 'Active' ? 'Paused' : 'Active' } : c))
    );
  };

  // Filters closed-won target leads for Phase 10 deliveries
  const closedWonLeads = leads.filter(l => l.status === 'Closed Won' || l.status === 'Proposal Sent');

  return (
    <div className="min-h-screen bg-[#050505] text-[#e0e0e0] flex flex-col antialiased selection:bg-[#00FFC2]/20">
      {/* Top operational navigation telemetry banner bar */}
      <header className="bg-[#0a0a0a] border-b border-white/10 py-3.5 px-6 flex justify-between items-center z-35 font-mono text-xs shadow-md">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-3.5 h-3.5 bg-[#00FFC2] rounded-full shadow-[0_0_8px_#00FFC2] animate-pulse"></div>
            <span className="text-lg font-bold tracking-tighter text-white font-sans">
              AXON.<span className="italic font-serif opacity-70">operator</span>
            </span>
          </div>
          <span className="text-white/20">|</span>
          <span className="font-serif italic text-sm tracking-tight text-white/90">
            Strategic Operations Center
          </span>
        </div>

        {/* Global Live date ticker */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-[10px] text-white/70 bg-black/45 border border-white/10 px-3 py-1 rounded-full font-mono">
            <span className="h-1.5 w-1.5 rounded-full bg-[#00FFC2] animate-pulse"></span>
            <span>OPERATOR: {session.user.email}</span>
          </div>
          <div className="hidden lg:flex items-center space-x-2 text-[10px] text-white/50 bg-[#050505] border border-white/10 px-3 py-1 rounded-full">
            <span className="h-1.5 w-1.5 rounded-full bg-[#00FFC2] mr-1 shadow-[0_0_6px_#00FFC2]"></span>
            <span>Active Instance: NYC-01</span>
          </div>
          <div className="text-[10px] text-[#00FFC2] bg-[#00FFC2]/5 border border-[#00FFC2]/20 px-3 py-1 rounded-full font-mono">
            <span>SYS CLOCK: 2026-05-31 UTC</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Left global dashboard sidebar navigations */}
        <nav className="w-full lg:w-64 bg-[#0a0a0a] border-r border-white/10 p-5 shrink-0 flex flex-col justify-between space-y-6">
          <div className="space-y-5">
            <div className="text-[10px] text-white/40 font-mono tracking-wider uppercase font-bold border-b border-white/10 pb-2 flex items-center space-x-1">
              <Compass size={12} className="text-[#00FFC2]" />
              <span>Agency Workflow Modules</span>
            </div>

            <div className="space-y-1 flex flex-col">
              {/* Tab 1: Market Research */}
              <button
                onClick={() => setActiveTab('intel')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'intel'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <Target size={15} />
                <span>Phase 1 — Market Intel</span>
              </button>

              {/* Tab 2: Leads Database */}
              <button
                onClick={() => setActiveTab('crm')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'crm'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <Users size={15} />
                <span>Phase 2 — Leads CRM</span>
              </button>

              {/* Tab 3: Detailed Audits */}
              <button
                onClick={() => setActiveTab('audits')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'audits'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <Activity size={15} />
                <span>Phase 3 — AI Audits</span>
              </button>

              {/* Tab 4: Outreach Factory */}
              <button
                onClick={() => setActiveTab('outreach')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'outreach'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <Send size={15} />
                <span>Phase 4 — Outreach Suite</span>
              </button>

              {/* Tab 5: Outbound Monitor */}
              <button
                onClick={() => setActiveTab('campaigns')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'campaigns'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <CheckCircle size={15} />
                <span>Phase 5 — Outbound Pulse</span>
              </button>

              {/* Tab 6: Conversational objections */}
              <button
                onClick={() => setActiveTab('qualifier')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'qualifier'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <Calendar size={15} />
                <span>Phase 6 — Inbound Triage</span>
              </button>

              {/* Tab 7: Proposal Room */}
              <button
                onClick={() => setActiveTab('proposals')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'proposals'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <FileText size={15} />
                <span>Phase 7-8 — Contracts Node</span>
              </button>

              {/* Tab 8: billing Ledger */}
              <button
                onClick={() => setActiveTab('billing')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'billing'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <CreditCard size={15} />
                <span>Phase 9 — Financial Ledger</span>
              </button>

              {/* Tab 9: Onboarding widget Preview */}
              <button
                onClick={() => setActiveTab('delivery')}
                className={`flex items-center space-x-3 px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer ${
                  activeTab === 'delivery'
                    ? 'bg-[#00FFC2]/5 border-[#00FFC2]/20 text-[#00FFC2] font-semibold'
                    : 'bg-transparent border-transparent text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <Briefcase size={15} />
                <span>Phase 10 — Client Deliveries</span>
              </button>

              {/* Tab 10: Real-World Activation (Go Live) */}
              <button
                onClick={() => setActiveTab('activation')}
                className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border font-sans text-xs transition duration-200 text-left cursor-pointer relative ${
                  activeTab === 'activation'
                    ? 'bg-[#00FFC2]/10 border-[#00FFC2]/30 text-[#00FFC2] font-semibold'
                    : 'bg-[#00FFC2]/5 border-[#00FFC2]/15 text-white hover:text-white hover:bg-[#00FFC2]/10'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Sparkles className="animate-pulse" size={15} />
                  <span>Real-World Activation</span>
                </div>
                <span className="text-[8px] bg-[#00FFC2] text-black px-1.5 py-0.2 rounded font-mono font-extrabold uppercase animate-pulse">Go Live</span>
              </button>
            </div>
          </div>

          {/* System status details resembling design footer constraints */}
          <div className="space-y-3">
            <div className="bg-[#00FFC2]/5 border border-[#00FFC2]/20 p-4 rounded-xl font-mono text-[10px]">
              <div className="flex justify-between items-center mb-1.5">
                <span className="font-bold text-[#00FFC2] uppercase">System Integrity</span>
                <span className="text-[#00FFC2]">99.8%</span>
              </div>
              <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                <div className="w-[99.8%] h-full bg-[#00FFC2]"></div>
              </div>
            </div>

            {/* Quick Target workspace indicator */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-3.5 space-y-2 text-[11px] font-mono leading-relaxed">
              <span className="text-[10px] text-white/40 uppercase tracking-widest block font-bold">Active Lead:</span>
              {selectedLead ? (
                <div className="space-y-1">
                  <span className="text-white text-xs block font-bold truncate">{selectedLead.businessName}</span>
                  <span className="text-[#00FFC2] block truncate font-serif italic">{selectedLead.ownerName}</span>
                  <span className="text-[9.5px] bg-[#00FFC2]/15 text-[#00FFC2] border border-[#00FFC2]/10 px-2 py-0.5 rounded uppercase mt-1 inline-block font-sans font-medium">
                    {selectedLead.status}
                  </span>
                </div>
              ) : (
                <span className="text-white/40 block italic">CRM Target Unloaded</span>
              )}
            </div>
          </div>
        </nav>

        {/* Dynamic work center viewport */}
        <main className="flex-1 p-6 lg:p-8 space-y-6 overflow-y-auto max-w-7xl mx-auto w-full">
          {/* Autonomous background automation loop block */}
          <AutonomousAutomator
            leads={leads}
            transactions={transactions}
            appointments={appointments}
            tasks={tasks}
            onAddLead={handleAddLead}
            onUpdateLeadAudit={handleUpdateLeadAudit}
            onUpdateStatus={handleUpdateStatus}
            onAddAppointment={handleAddAppointment}
            onRecordMobilizationTransaction={handleRecordMobilizationTransaction}
            onSettleInvoice={handleSettleInvoice}
            onAddTask={handleAddTask}
          />

          {/* Global Statistics Banner Dashboard Header ticker */}
          <DashboardStats
            leads={leads}
            transactions={transactions}
            appointments={appointments}
            apiStatus={apiStatus}
          />

          {/* Core Panel view switchers */}
          <div className="animate-fadeIn transition-opacity duration-300">
            {activeTab === 'intel' && (
              <MarketIntel
                opportunities={opportunities}
                onAddOpportunities={handleAddOpportunities}
              />
            )}

            {activeTab === 'crm' && (
              <LeadsCRM
                leads={leads}
                selectedLead={selectedLead}
                onSelectLead={setSelectedLead}
                onAddLead={handleAddLead}
                onDeleteLead={handleDeleteLead}
              />
            )}

            {activeTab === 'audits' && (
              <AuditDetails
                selectedLead={selectedLead}
                onUpdateLeadAudit={handleUpdateLeadAudit}
              />
            )}

            {activeTab === 'outreach' && (
              <OutreachFactory
                selectedLead={selectedLead}
                onMarkContacted={(id) => handleUpdateStatus(id, 'Contacted')}
                onIncrementOutboundStats={handleIncrementOutboundStats}
                gmailToken={gmailToken}
                gmailProfile={gmailProfile}
                onDisconnectGmail={handleDisconnectGmail}
                onConnectGmail={handleConnectGmail}
              />
            )}

            {activeTab === 'campaigns' && (
              <OutboundPulse
                campaigns={campaigns}
                onToggleStatus={handleToggleCampaignStatus}
              />
            )}

            {activeTab === 'qualifier' && (
              <CalendarInbound
                selectedLead={selectedLead}
                appointments={appointments}
                onAddAppointment={handleAddAppointment}
              />
            )}

            {activeTab === 'proposals' && (
              <ProposalRoom
                selectedLead={selectedLead}
                onUpdateStatus={handleUpdateStatus}
                onRecordMobilizationTransaction={handleRecordMobilizationTransaction}
              />
            )}

            {activeTab === 'billing' && (
              <FinancialLedger
                transactions={transactions}
                leads={leads}
                onSettleInvoice={handleSettleInvoice}
                onAddTransaction={handleAddTransaction}
              />
            )}

            {activeTab === 'delivery' && (
              <ServiceDelivery
                tasks={tasks}
                closedLeads={closedWonLeads}
                onToggleTask={handleToggleTask}
                onAddTask={handleAddTask}
              />
            )}

            {activeTab === 'activation' && (
              <RealWorldActivation
                leads={leads}
                gmailToken={gmailToken}
                gmailProfile={gmailProfile}
                onDisconnectGmail={handleDisconnectGmail}
                onConnectGmail={handleConnectGmail}
              />
            )}
          </div>
        </main>
      </div>

      {/* Global Bottom Ticker Bar */}
      <footer className="h-10 bg-[#0a0a0a] border-t border-white/5 flex items-center justify-between px-6 text-[9px] text-white/30 uppercase tracking-widest font-mono">
        <div className="flex items-center space-x-6">
          <span className="text-[#00FFC2] flex items-center"><span className="w-1 h-1 bg-[#00FFC2] rounded-full mr-1 px-0 py-0 inline-block animate-pulse"></span>US Cluster: active</span>
          <span>EU Cluster: active</span>
          <span>MENA Cluster: active</span>
        </div>
        <div>Engine Build: v4.2.0-AutoPropel</div>
      </footer>
    </div>
  );
}
