import React, { useState } from 'react';
import { ShieldCheck, HardHat, Sparkles, TrendingDown, Clock, HelpCircle, Activity, Globe, Loader2, DollarSign } from 'lucide-react';
import { Lead, AIAudit } from '../types';
import { secureFetch } from '../lib/api';

interface AuditDetailsProps {
  selectedLead: Lead | null;
  onUpdateLeadAudit: (leadId: string, audit: AIAudit) => void;
}

export default function AuditDetails({ selectedLead, onUpdateLeadAudit }: AuditDetailsProps) {
  const [isRunningAudit, setIsRunningAudit] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const triggerAIAudit = async () => {
    if (!selectedLead) return;
    setIsRunningAudit(true);
    setErrorMsg('');

    try {
      const response = await secureFetch('/api/agency/audit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          businessName: selectedLead.businessName,
          industry: selectedLead.industry,
          website: selectedLead.website,
          country: selectedLead.country,
          ownerName: selectedLead.ownerName
        })
      });

      if (!response.ok) {
        throw new Error('Audit engine responded with an error');
      }

      const auditResult: AIAudit = await response.json();
      onUpdateLeadAudit(selectedLead.id, auditResult);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Audit failed. Directing mock pipeline: ' + err.message);
    } finally {
      setIsRunningAudit(false);
    }
  };

  if (!selectedLead) {
    return (
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-12 text-center text-white/50 animate-fadeIn animate-duration-500">
        <Activity size={32} className="text-[#00FFC2] mx-auto mb-3 animate-pulse" />
        <h3 className="font-sans font-semibold text-lg text-white">No Lead Mounted in Work Station</h3>
        <p className="text-xs max-w-md mx-auto mt-2 leading-relaxed text-white/40">
          Select a premium prospective client from the <span className="font-semibold text-[#00FFC2]">Leads CRM Database</span> tab to perform targeted conversion audits and design multi-channel outreach campaigns.
        </p>
      </div>
    );
  }

  const audit = selectedLead.audit;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Prospect Overview Card */}
      <div className="bg-[#0a0a0a] border border-white/10 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-widest bg-white/5 text-white/60 px-2.5 py-0.5 rounded border border-white/5 font-semibold">Mount Workspace Target</span>
          <h2 className="text-2.5xl font-bold font-sans text-white mt-1.5 leading-snug">{selectedLead.businessName}</h2>
          <p className="text-white/40 text-xs font-mono mt-1 flex items-center space-x-2">
            <span>Website: {selectedLead.website}</span>
            <span>&bull;</span>
            <span className="font-serif italic text-white/60">Entity: {selectedLead.ownerName} ({selectedLead.country})</span>
          </p>
        </div>

        <button
          onClick={triggerAIAudit}
          disabled={isRunningAudit}
          className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans text-xs px-5 py-2.5 rounded-lg flex items-center space-x-2 font-bold cursor-pointer transition-all duration-300 self-start md:self-auto shadow-lg"
        >
          {isRunningAudit ? (
            <>
              <Loader2 className="animate-spin text-black" size={14} />
              <span>Scanning Domain Conversion Pixels...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} className="text-black" />
              <span>{audit ? 'Re-Run Conversion Audit' : 'Initiate Gemini Technical Audit'}</span>
            </>
          )}
        </button>
      </div>

      {errorMsg && (
        <div className="bg-amber-500/5 border border-amber-500/15 p-3 rounded-xl text-xs text-amber-400 font-mono">
          {errorMsg}
        </div>
      )}

      {!audit ? (
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-10 text-center space-y-4">
          <HardHat size={32} className="text-[#00FFC2] mx-auto animate-pulse" />
          <h3 className="font-sans font-medium text-white text-base">Friction Matrix Audit Uninitialized</h3>
          <p className="text-white/40 max-w-sm mx-auto text-xs leading-relaxed">
            We review their website speed, intake forms, booking processes, and calculate lost revenue. Click 'Initiate Gemini Technical Audit' to scan client leaks.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Key Audit Scores Visualizers */}
          <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-5">
            <h3 className="font-sans font-semibold text-white/90 border-b border-white/10 pb-3 text-sm">Friction Matrix Performance</h3>
            
            <div className="space-y-4 text-xs font-mono">
              {/* Score Indicator Helper */}
              {Object.entries({
                'Website Core Speed': audit.scores.websiteSpeed,
                'Mobile Responsiveness': audit.scores.mobileOptimized,
                'Search Engine Visibility (SEO)': audit.scores.seoRank,
                'Low-Friction Signups': audit.scores.leadForms,
                'Immediate Call-Back Speed': audit.scores.followUpSystems,
                'Instant Self-Booking Path': audit.scores.appointmentBooking,
                'Off-hours Intelligent Assistant': audit.scores.customerSupport,
              }).map(([label, score], idx) => {
                const isCritical = score < 60;
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-white/50">{label}</span>
                      <span className={isCritical ? 'text-rose-400 font-semibold' : 'text-[#00FFC2] font-semibold'}>
                        {score}/100 {isCritical ? '[CRITICAL]' : ''}
                      </span>
                    </div>
                    {/* Progress Track */}
                    <div className="w-full bg-[#050505] h-2 rounded border border-white/5 overflow-hidden">
                      <div
                        className={`h-full transition-all duration-1000 ${
                          isCritical ? 'bg-gradient-to-r from-red-650 to-rose-400' : 'bg-[#00FFC2]'
                        }`}
                        style={{ width: `${score}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-2 space-y-6">
            {/* Monetary Revenue Lost Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-[#0a0a0a] to-[#050505] border border-white/10 rounded-2xl p-5 flex items-center space-x-4">
                <div className="p-3 bg-rose-950/20 text-rose-400 rounded-xl border border-rose-500/10">
                  <TrendingDown size={24} />
                </div>
                <div>
                  <span className="text-[10px] text-white/40 font-mono uppercase tracking-wider block">Estimated Leakage Volume</span>
                  <h4 className="text-2xl font-bold font-sans text-rose-400 mt-0.5">
                    ${audit.estimatedRevenueLost.toLocaleString()} <span className="text-[11px] font-mono text-white/30 font-normal">/ yr</span>
                  </h4>
                  <p className="text-[10px] text-white/40 mt-1">Annually due to delayed responses & manual drops.</p>
                </div>
              </div>

              <div className="bg-gradient-to-br from-[#0a0a0a] to-[#050505] border border-white/10 rounded-2xl p-5 flex items-center space-x-4">
                <div className="p-3 bg-[#00FFC2]/10 text-[#00FFC2] rounded-xl border border-[#00FFC2]/20">
                  <ShieldCheck size={24} />
                </div>
                <div>
                  <span className="text-[10px] text-white/40 font-mono uppercase tracking-wider block">Uncapped Potential Gain</span>
                  <h4 className="text-[15px] font-bold font-sans text-[#00FFC2] mt-0.5" title={audit.revenueOpportunity}>
                    {audit.revenueOpportunity.length > 50 ? `${audit.revenueOpportunity.slice(0, 48)}...` : audit.revenueOpportunity}
                  </h4>
                  <p className="text-[10px] text-white/40 mt-1">Reclaimable under instant autonomous intake.</p>
                </div>
              </div>
            </div>

            {/* AI Personal Audit Paragraph */}
            <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-3">
              <span className="text-[10px] text-[#00FFC2] font-mono uppercase tracking-widest block font-bold border-b border-white/10 pb-2">Analysis Findings (Personalized Narrative)</span>
              <p className="text-white/80 text-xs leading-relaxed font-sans font-normal italic">
                "{audit.personalizedAuditSummary}"
              </p>
              <div className="flex items-center space-x-2 pt-2 text-[10px] text-white/30 font-mono">
                <Clock size={12} />
                <span>Triggered on {new Date(audit.completedAt).toLocaleDateString()} at {new Date(audit.completedAt).toLocaleTimeString()}</span>
              </div>
            </div>

            {/* Deliverable/Opp Actions & Tech Stack */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Proposed Automations */}
              <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 space-y-3">
                <span className="text-[10px] text-white/70 font-mono uppercase tracking-wider block font-semibold">Priority Operations Needed:</span>
                <ul className="space-y-2">
                  {audit.automationOpportunities.map((op, i) => (
                    <li key={i} className="text-[11px] text-white/55 pl-3 border-l border-[#00FFC2]/50 leading-relaxed font-sans">
                      {op}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Technologies Required */}
              <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 space-y-3 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] text-white/70 font-mono uppercase tracking-wider block font-semibold mb-2">Recommended Middleware Core:</span>
                  <div className="flex flex-wrap gap-1.5 font-mono">
                    {audit.suggestedStack.map((tech, i) => (
                      <span key={i} className="text-[10px] bg-[#050505] text-[#00FFC2] border border-white/5 px-2 py-0.5 rounded">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 mt-4 text-[10px] text-white/30 font-mono">
                  &bull; Automatically injects custom webhook triggers in CRM.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
