import React, { useState, useEffect, useRef } from 'react';
import { OBDAppointment, Lead } from '../types';
import { Calendar, HelpCircle, Check, Loader2, Sparkles, MessageSquare, Send, PhoneOutgoing, User, ShieldCheck } from 'lucide-react';
import { secureFetch } from '../lib/api';

interface CalendarInboundProps {
  selectedLead: Lead | null;
  appointments: OBDAppointment[];
  onAddAppointment: (appt: OBDAppointment) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'representative' | 'prospect';
  text: string;
  timestamp: string;
}

export default function CalendarInbound({ selectedLead, appointments, onAddAppointment }: CalendarInboundProps) {
  const [googleSynced, setGoogleSynced] = useState(true);
  const [calComSynced, setCalComSynced] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Chat Objections Simulator states
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isProspectTyping, setIsProspectTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Re-initialize conversational chatter every time lead switches
  useEffect(() => {
    if (selectedLead) {
      setChatMessages([
        {
          id: "m1",
          sender: "prospect",
          text: `Hi, I saw your Loom video audit regarding our intake delays at ${selectedLead.businessName}. To be honest, we are quite busy. Is this system going to take months for our teams to set up?`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } else {
      setChatMessages([]);
    }
  }, [selectedLead]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isProspectTyping]);

  const handleSyncGateways = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setCalComSynced(true);
      setIsSyncing(false);
    }, 1000);
  };

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || !selectedLead) return;

    // Append our response message
    const userMsg: ChatMessage = {
      id: "usr_" + Date.now(),
      sender: "representative",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedHistory = [...chatMessages, userMsg];
    setChatMessages(updatedHistory);
    setInputText('');
    setIsProspectTyping(true);

    try {
      const response = await secureFetch('/api/agency/chat-qualify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedHistory,
          lead: selectedLead
        })
      });

      if (!response.ok) {
        throw new Error('Skeptical agent response failed');
      }

      const reply = await response.json();
      setChatMessages(prev => [
        ...prev,
        {
          id: "pro_" + Date.now(),
          sender: "prospect",
          text: reply.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err: any) {
      console.error(err);
      // Fallback response simulation
      setTimeout(() => {
        setChatMessages(prev => [
          ...prev,
          {
            id: "pro_err_" + Date.now(),
            sender: "prospect",
            text: "That answers some of my questions on security. If you guys can show me a real dashboard demo of how it schedules leads into my direct calendar, we can talk next week.",
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }, 1000);
    } finally {
      setIsProspectTyping(false);
    }
  };

  const triggerObjectionAction = (preValue: string) => {
    handleSendMessage(preValue);
  };

  const handleAutoBookAppointment = () => {
    if (!selectedLead) return;
    const isAlreadyBooked = appointments.some(a => a.leadId === selectedLead.id);
    if (isAlreadyBooked) return;

    const newAppt: OBDAppointment = {
      id: "appt_" + Date.now(),
      leadId: selectedLead.id,
      leadName: selectedLead.ownerName,
      businessName: selectedLead.businessName,
      dateTime: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0] + "T14:00:00Z",
      status: "Scheduled",
      summary: "Autonomous objection solved appointment booked via conversational chat qualifier.",
      googleCalendarSynced: googleSynced,
      calComSynced: calComSynced
    };

    onAddAppointment(newAppt);
    
    // Add success message in chat
    setChatMessages(prev => [
      ...prev,
      {
        id: "sys_book" + Date.now(),
        sender: "prospect",
        text: "Outstanding. I have selected your Tuesday calendar slot. Our CRM coordination credentials have been dispatched.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Calendar integration switches */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 font-mono text-xs">
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-[#00FFC2] animate-pulse"></span>
            <span className="text-white uppercase font-bold tracking-widest text-[11px] font-sans">Active Scheduler Gates:</span>
          </div>

          <div className="flex items-center space-x-1.5 px-3 py-1 bg-[#050505] border border-white/5 rounded-lg text-white/80">
            <input
              type="checkbox"
              id="google"
              checked={googleSynced}
              onChange={() => setGoogleSynced(!googleSynced)}
              className="accent-[#00FFC2]"
            />
            <label htmlFor="google" className="text-white/60 text-[10px] font-sans cursor-pointer font-medium">Google Calendar Linked</label>
          </div>

          <div className="flex items-center space-x-1.5 px-3 py-1 bg-[#050505] border border-white/5 rounded-lg text-white/80">
            <input
              type="checkbox"
              id="cal"
              checked={calComSynced}
              onChange={() => setCalComSynced(!calComSynced)}
              className="accent-[#00FFC2]"
            />
            <label htmlFor="cal" className="text-white/60 text-[10px] font-sans cursor-pointer font-medium">Cal.com Live Gateway</label>
          </div>
        </div>

        <button
          onClick={handleSyncGateways}
          disabled={isSyncing || calComSynced}
          className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans font-bold px-4 py-1.5 rounded-lg transition text-[11px] cursor-pointer shrink-0"
        >
          {isSyncing ? 'Syncing Gateways...' : calComSynced ? 'Gateways Confirmed \u2713' : 'Link Cal.com Platform'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Appointment Scheduler Records list */}
        <div className="lg:col-span-1 bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4">
          <h3 className="text-white font-sans font-medium text-sm border-b border-white/10 pb-3 flex items-center space-x-2">
            <Calendar className="text-[#00FFC2]" size={16} />
            <span>Active Meetings booked</span>
          </h3>

          <div className="space-y-4 max-h-[430px] overflow-y-auto pr-1">
            {appointments.map((appt) => (
              <div key={appt.id} className="bg-[#050505] border border-white/5 rounded-xl p-3.5 space-y-2.5 font-mono text-[11px]">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-white font-sans font-bold text-xs leading-none">{appt.businessName}</span>
                    <p className="text-white/40 text-[10px] mt-0.5">Contact: {appt.leadName}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-wider ${
                    appt.status === 'Completed' ? 'bg-white/5 text-white/50 border border-white/10' : 'bg-[#00FFC2]/15 text-[#00FFC2] border border-[#00FFC2]/30'
                  }`}>
                    {appt.status}
                  </span>
                </div>

                <div className="text-[10px] text-white/60 leading-relaxed font-sans bg-white/5 p-2 rounded">
                  {appt.summary}
                </div>

                <div className="flex border-t border-white/5 pt-2 text-[9px] text-white/30 justify-between">
                  <span>DATE: {new Date(appt.dateTime).toLocaleDateString()}</span>
                  <span>SYNC: {appt.googleCalendarSynced ? 'G-Cal \u2713' : 'N/A'} {appt.calComSynced ? 'Cal \u2713' : 'N/A'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live objection training sandbox */}
        <div className="lg:col-span-2 bg-[#0a0a0a] border border-white/10 rounded-2xl flex flex-col h-[520px] overflow-hidden">
          <div className="px-5 py-3.5 bg-[#050505] border-b border-white/10 flex items-center justify-between">
            <div>
              <span className="text-[9px] uppercase font-mono tracking-wider bg-white/5 text-[#00FFC2] px-2.2 py-0.5 rounded mr-1.5 font-bold">Training Module</span>
              <span className="font-sans font-medium text-white text-sm">Objections Conversion Sandbox</span>
            </div>
            {selectedLead && (
              <span className="text-xs font-mono text-[#00FFC2]">Prospect: {selectedLead.ownerName}</span>
            )}
          </div>

          {!selectedLead ? (
            <div className="flex-1 flex flex-col justify-center items-center text-white/30 p-8 font-sans text-center">
              <MessageSquare className="text-white/10 mb-2 animate-bounce" size={32} />
              <p className="text-sm">Please select a target client in CRM to initialize objection simulator.</p>
            </div>
          ) : (
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Messages track */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4 font-mono text-[11px] leading-relaxed">
                {chatMessages.map((msg) => {
                  const isUser = msg.sender === 'representative';
                  return (
                    <div key={msg.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] rounded-2xl p-4 ${
                        isUser 
                          ? 'bg-white/5 border border-white/10 text-white rounded-br-none' 
                          : 'bg-[#050505] border border-white/5 text-white/80 rounded-bl-none'
                      }`}>
                        <div className="flex items-center space-x-1 mb-1 font-sans font-bold text-[10px] text-white/40">
                          <User size={10} />
                          <span>{isUser ? 'Representative Operator' : selectedLead.ownerName}</span>
                          <span className="text-[9px] text-white/30 font-normal">({msg.timestamp})</span>
                        </div>
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                      </div>
                    </div>
                  );
                })}

                {isProspectTyping && (
                  <div className="flex justify-start">
                    <div className="bg-[#050505] border border-white/5 rounded-xl p-3 text-white/40 flex items-center space-x-2">
                      <Loader2 className="animate-spin text-[#00FFC2]" size={14} />
                      <span>Prospect is thinking... drafting compliance counter-questions</span>
                    </div>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Instant pre-formulated objections answers triggers helper */}
              <div className="p-3 bg-[#050505] border-t border-white/10 space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-white/40 block">Deploy Strategy Counter-Strike:</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => triggerObjectionAction("Our implementation is highly managed and rapid. We can live-verify our core SMS webhook within 45 seconds using standard CRM API connections. It requires zero coding work from your side.")}
                    className="bg-white/5 hover:bg-white/10 text-[10px] font-mono border border-white/10 text-white px-3 py-1.5 rounded transition cursor-pointer"
                  >
                    🚀 Fast Setup Guarantee
                  </button>
                  <button
                    onClick={() => triggerObjectionAction("We configure absolute accuracy parameters. Our middleware monitors conversational outputs over a private API channel, ensuring the system strictly books slots and doesn't hallucinate pricing.")}
                    className="bg-white/5 hover:bg-white/10 text-[10px] font-mono border border-white/10 text-white px-3 py-1.5 rounded transition cursor-pointer"
                  >
                    🔒 Hallucination / Safety
                  </button>
                  <button
                    onClick={() => triggerObjectionAction("Our hybrid model is performance-based. We run a 25% mobilization fee to cover licensing costs, while the rest are coupled directly to qualified lead outcomes on your calendar.")}
                    className="bg-white/5 hover:bg-white/10 text-[10px] font-mono border border-white/10 text-white px-3 py-1.5 rounded transition cursor-pointer"
                  >
                    💰 Model Pricing Pitch
                  </button>

                  <button
                    onClick={handleAutoBookAppointment}
                    className="bg-[#00FFC2]/10 border border-[#00FFC2]/30 text-[#00FFC2] hover:bg-[#00FFC2]/20 text-[10px] font-mono px-3 py-1.5 rounded transition cursor-pointer font-bold flex items-center space-x-1 ml-auto"
                  >
                    <Sparkles size={11} className="text-[#00FFC2]" />
                    <span>Trigger Cal.com Booking</span>
                  </button>
                </div>
              </div>

              {/* Chat Text Input */}
              <div className="p-3 bg-[#050505] border-t border-white/10 flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Type objection reply or pitch answer..."
                  className="flex-1 bg-white/5 border border-white/5 rounded-lg px-4 py-2 font-mono text-xs text-white focus:outline-none focus:border-[#00FFC2]"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSendMessage(inputText);
                  }}
                />
                <button
                  onClick={() => handleSendMessage(inputText)}
                  className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black p-2.5 rounded-lg cursor-pointer transition shrink-0"
                >
                  <Send size={14} className="text-black" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
