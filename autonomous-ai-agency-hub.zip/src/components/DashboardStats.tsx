import React from 'react';
import { Shield, Sparkles, TrendingUp, Users, DollarSign, Calendar } from 'lucide-react';
import { Lead, FinancialTransaction, OBDAppointment } from '../types';

interface DashboardStatsProps {
  leads: Lead[];
  transactions: FinancialTransaction[];
  appointments: OBDAppointment[];
  apiStatus: { configured: boolean; message: string };
}

export default function DashboardStats({ leads, transactions, appointments, apiStatus }: DashboardStatsProps) {
  const totalLeadsCount = leads.length;
  const closedWonCount = leads.filter(l => l.status === 'Closed Won').length;
  const totalContractPipelineValue = leads
    .filter(l => l.status !== 'Closed Lost')
    .reduce((sum, l) => sum + (l.dealSize ?? 10000), 0);

  const totalCollectedUpfront = transactions
    .filter(t => t.status === 'Paid')
    .reduce((sum, t) => sum + t.amount, 0);

  const activeMeetingsCount = appointments.filter(a => a.status === 'Scheduled').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
      {/* Stat 1: Total Leads */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 flex items-center space-x-4 relative overflow-hidden group hover:border-[#00FFC2]/30 transition-all duration-300">
        <div className="p-3 bg-[#00FFC2]/5 text-[#00FFC2] rounded-lg">
          <Users size={20} />
        </div>
        <div>
          <p className="text-xs text-white/40 font-mono tracking-wider uppercase">CRM Core Leads</p>
          <div className="flex items-baseline space-x-2">
            <h3 className="text-2xl font-semibold font-display text-white">{totalLeadsCount}</h3>
            <span className="text-xs text-[#00FFC2] font-mono font-medium">+{leads.filter(l => l.status === 'Lead').length} new</span>
          </div>
        </div>
        <div className="absolute top-0 right-0 h-16 w-16 bg-[#00FFC2]/2 rounded-full blur-xl group-hover:bg-[#00FFC2]/5 transition-all duration-300"></div>
      </div>

      {/* Stat 2: Pipeline Capital */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 flex items-center space-x-4 relative overflow-hidden group hover:border-[#00FFC2]/30 transition-all duration-300">
        <div className="p-3 bg-[#00FFC2]/5 text-[#00FFC2] rounded-lg">
          <TrendingUp size={20} />
        </div>
        <div>
          <p className="text-xs text-white/40 font-mono tracking-wider uppercase">Total Pipeline</p>
          <div className="flex items-baseline space-x-2">
            <h3 className="text-2xl font-semibold font-display text-white">${(totalContractPipelineValue / 1000).toFixed(0)}k</h3>
            <span className="text-xs text-white/60 font-mono font-medium">Avg ${((totalContractPipelineValue / (totalLeadsCount || 1)) / 1000).toFixed(1)}k</span>
          </div>
        </div>
        <div className="absolute top-0 right-0 h-16 w-16 bg-[#00FFC2]/2 rounded-full blur-xl group-hover:bg-[#00FFC2]/5 transition-all duration-300"></div>
      </div>

      {/* Stat 3: Mobilized Upfront Revenue */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 flex items-center space-x-4 relative overflow-hidden group hover:border-[#00FFC2]/30 transition-all duration-300">
        <div className="p-3 bg-[#00FFC2]/5 text-[#00FFC2] rounded-lg">
          <DollarSign size={20} />
        </div>
        <div>
          <p className="text-xs text-white/40 font-mono tracking-wider uppercase">Retained Income</p>
          <div className="flex items-baseline space-x-2">
            <h3 className="text-2xl font-semibold font-display text-white">${totalCollectedUpfront.toLocaleString()}</h3>
            <span className="text-xs text-[#00FFC2] font-mono font-medium">WM {closedWonCount} contracts</span>
          </div>
        </div>
        <div className="absolute top-0 right-0 h-16 w-16 bg-[#00FFC2]/2 rounded-full blur-xl group-hover:bg-[#00FFC2]/5 transition-all duration-300"></div>
      </div>

      {/* Stat 4: Active Appointments */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 flex items-center space-x-4 relative overflow-hidden group hover:border-[#00FFC2]/30 transition-all duration-300">
        <div className="p-3 bg-[#00FFC2]/5 text-[#00FFC2] rounded-lg">
          <Calendar size={20} />
        </div>
        <div>
          <p className="text-xs text-white/40 font-mono tracking-wider uppercase">Active Meetings</p>
          <div className="flex items-baseline space-x-2">
            <h3 className="text-2xl font-semibold font-display text-white">{activeMeetingsCount}</h3>
            <span className="text-xs text-white/40 font-mono">Cal.com Active</span>
          </div>
        </div>
        <div className="absolute top-0 right-0 h-16 w-16 bg-[#00FFC2]/2 rounded-full blur-xl group-hover:bg-[#00FFC2]/5 transition-all duration-300"></div>
      </div>

      {/* Stat 5: AI Core Telemetry */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-xl p-4 flex items-center space-x-4 relative overflow-hidden group hover:border-[#00FFC2]/30 transition-all duration-300">
        <div className={`p-3 rounded-lg bg-[#00FFC2]/5 text-[#00FFC2]`}>
          <Shield size={20} />
        </div>
        <div>
          <p className="text-xs text-white/40 font-mono tracking-wider uppercase">AI Core Status</p>
          <div className="flex items-center space-x-2 mt-0.5">
            <span className={`h-2 w-2 rounded-full bg-[#00FFC2] shadow-[0_0_6px_#00FFC2] animate-pulse`}></span>
            <span className="text-xs font-mono font-medium text-white">
              {apiStatus.configured ? 'ACTIVE ENGINE' : 'SIM TELEMETRY'}
            </span>
          </div>
          <p className="text-[10px] text-white/30 truncate font-mono mt-0.5 max-w-[130px]" title={apiStatus.message}>
            {apiStatus.message}
          </p>
        </div>
        <div className="absolute top-0 right-0 h-16 w-16 bg-[#00FFC2]/2 rounded-full blur-xl group-hover:bg-[#00FFC2]/5 transition-all duration-300"></div>
      </div>
    </div>
  );
}
