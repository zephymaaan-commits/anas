import React, { useState } from 'react';
import { 
  Briefcase, 
  MapPin, 
  Mail, 
  Linkedin, 
  Plus, 
  Filter, 
  MessageSquare, 
  AlertCircle, 
  Trash2, 
  HeartHandshake,
  Search,
  Globe,
  RefreshCw,
  Sparkles,
  Check,
  ArrowRight
} from 'lucide-react';
import { Lead } from '../types';
import { secureFetch } from '../lib/api';

interface LeadsCRMProps {
  leads: Lead[];
  onSelectLead: (lead: Lead) => void;
  selectedLead: Lead | null;
  onAddLead: (lead: Lead) => void;
  onDeleteLead?: (leadId: string) => void;
}

export default function LeadsCRM({ leads, onSelectLead, selectedLead, onAddLead, onDeleteLead }: LeadsCRMProps) {
  const [filterCountry, setFilterCountry] = useState('All');
  const [filterIndustry, setFilterIndustry] = useState('All');

  // Input states for New Lead Logger Form
  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [website, setWebsite] = useState('');
  const [linkedIn, setLinkedIn] = useState('');
  const [country, setCountry] = useState('United States');
  const [industry, setIndustry] = useState('High-Ticket Real Estate Brokerages');
  const [revenue, setRevenue] = useState('$5.0M / yr');
  const [employees, setEmployees] = useState(15);
  const [showAddForm, setShowAddForm] = useState(false);

  // States for Smart Real-Client Finder (AI/Live Search Scraper)
  const [showScrapeForm, setShowScrapeForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchIndustry, setSearchIndustry] = useState('High-Ticket Real Estate Brokerages');
  const [searchCountry, setSearchCountry] = useState('United States');
  const [discoveredLeads, setDiscoveredLeads] = useState<Lead[]>([]);
  const [isScraping, setIsScraping] = useState(false);
  const [scrapedStatus, setScrapedStatus] = useState('');
  const [importedIds, setImportedIds] = useState<string[]>([]);

  const handleAddNewLead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName.trim() || !ownerName.trim()) return;

    const newLead: Lead = {
      id: "lead_" + Date.now(),
      businessName,
      industry,
      ownerName,
      email,
      phone,
      website: website || `${businessName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
      linkedIn: linkedIn || `linkedin.com/company/${businessName.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      country,
      revenueEstimate: revenue,
      employeeCount: Number(employees),
      status: 'Lead',
      notes: 'Added via autonomous operations terminal interface.',
      dealSize: industry.includes('Legal') || industry.includes('Law') ? 18000 : 12000
    };

    onAddLead(newLead);
    setBusinessName('');
    setOwnerName('');
    setEmail('');
    setPhone('');
    setWebsite('');
    setLinkedIn('');
    setShowAddForm(false);
  };

  const handleScrapeLiveLeads = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsScraping(true);
    setScrapedStatus('Connecting to Gemini Search Grounding agent...');
    setDiscoveredLeads([]);
    
    try {
      const response = await secureFetch('/api/agency/real-leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: searchQuery,
          industry: searchIndustry,
          country: searchCountry
        })
      });
      
      if (!response.ok) {
        throw new Error('Lead search service is temporarily throttled.');
      }
      
      const data = await response.json();
      setDiscoveredLeads(data);
      setScrapedStatus('');
    } catch (err: any) {
      console.error(err);
      setScrapedStatus('Could not complete live search. Running local backup data search index.');
    } finally {
      setIsScraping(false);
    }
  };

  const handleImportLead = (scrapedLead: Lead) => {
    const importedLead: Lead = {
      ...scrapedLead,
      id: "lead_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
      status: 'Lead', // Reset status as brand new target
      notes: scrapedLead.notes || `Scoured using real-time search criteria. Ready for immediate technical optimization audit.`
    };
    onAddLead(importedLead);
    setImportedIds(prev => [...prev, scrapedLead.id]);
  };

  // Extract unique industries & countries for filtration lists
  const industriesList = Array.from(new Set(leads.map(l => l.industry)));
  const countriesList = Array.from(new Set(leads.map(l => l.country)));

  // Filter leads
  const filteredLeads = leads.filter(l => {
    const matchCountry = filterCountry === 'All' || l.country === filterCountry;
    const matchIndustry = filterIndustry === 'All' || l.industry === filterIndustry;
    return matchCountry && matchIndustry;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Filters & Actions Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#0a0a0a] border border-white/10 p-4 rounded-xl text-xs font-mono">
        <div className="flex flex-wrap items-center gap-4">
          {/* Industry Filter */}
          <div className="flex items-center space-x-2">
            <Filter size={14} className="text-[#00FFC2]" />
            <span className="text-white/40 uppercase tracking-wider text-[10px]">Filter Core:</span>
            <select
              className="bg-[#050505] border border-white/10 rounded px-2 py-1 text-white focus:outline-none focus:border-[#00FFC2] font-mono text-xs"
              value={filterIndustry}
              onChange={(e) => setFilterIndustry(e.target.value)}
            >
              <option value="All">All Niche Industries</option>
              {industriesList.map((ind, i) => (
                <option key={i} value={ind}>{ind}</option>
              ))}
            </select>
          </div>

          {/* Country Filter */}
          <div className="flex items-center space-x-2">
            <MapPin size={14} className="text-[#00FFC2]" />
            <select
              className="bg-[#050505] border border-white/10 rounded px-2 py-1 text-white focus:outline-none focus:border-[#00FFC2] font-mono text-xs"
              value={filterCountry}
              onChange={(e) => setFilterCountry(e.target.value)}
            >
              <option value="All">All Territories</option>
              {countriesList.map((cty, i) => (
                <option key={i} value={cty}>{cty}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Smart Web Scraper trigger */}
          <button
            onClick={() => {
              setShowScrapeForm(!showScrapeForm);
              setShowAddForm(false);
            }}
            className={`bg-gradient-to-r from-[#00FFC1] to-teal-500 font-sans font-bold px-4 py-2 rounded-lg flex items-center space-x-2 cursor-pointer hover:opacity-90 shadow-lg text-black text-xs transition`}
          >
            <Sparkles size={14} className="text-black" />
            <span>Smart Real-Client Finder</span>
          </button>

          {/* Manual Logger Trigger */}
          <button
            onClick={() => {
              setShowAddForm(!showAddForm);
              setShowScrapeForm(false);
            }}
            className="bg-white/5 hover:bg-white/10 text-white border border-white/10 font-sans font-medium px-4 py-2 rounded-lg flex items-center space-x-2 cursor-pointer transition text-xs"
          >
            <Plus size={14} className="text-white/80" />
            <span>Manual Entry</span>
          </button>
        </div>
      </div>

      {/* Slide down Intelligent Web Scraper / Real Client Finder */}
      {showScrapeForm && (
        <div className="bg-[#0a0a0a] border border-white/10 p-5 rounded-2xl text-xs font-mono">
          <div className="border-b border-white/10 pb-3 mb-4 flex items-center justify-between">
            <span className="text-sm font-sans font-semibold text-white/90 flex items-center space-x-2">
              <Search className="text-[#00FFC2]" size={16} />
              <span>Scour Live Web for Actual Operating Businesses</span>
            </span>
            <button type="button" onClick={() => setShowScrapeForm(false)} className="text-white/40 hover:text-white cursor-pointer font-sans text-lg">&times;</button>
          </div>

          <form onSubmit={handleScrapeLiveLeads} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
            <div className="space-y-1 bg-[#030303] border border-white/5 p-3 rounded-xl">
              <label className="text-white/40 uppercase tracking-wider text-[10px] block font-semibold mb-1">1. Target Sector Niche</label>
              <select
                className="w-full bg-[#050505] border border-white/10 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-[#00FFC2] font-mono"
                value={searchIndustry}
                onChange={(e) => setSearchIndustry(e.target.value)}
              >
                <option value="High-Ticket Real Estate Brokerages">High-Ticket Real Estate Brokerages</option>
                <option value="Premium Solar & CleanTech Installers">Premium Solar & CleanTech Installers</option>
                <option value="Personal Injury & Corporate Law Firms">Personal Injury & Corporate Law Firms</option>
                <option value="Specialized Orthodontic & Aesthetic Dental Clinics">Specialized Orthodontic & Aesthetic Dental Clinics</option>
                <option value="Enterprise SaaS & B2B Software Companies">Enterprise SaaS & B2B Software Companies</option>
              </select>
            </div>

            <div className="space-y-1 bg-[#030303] border border-white/5 p-3 rounded-xl">
              <label className="text-white/40 uppercase tracking-wider text-[10px] block font-semibold mb-1">2. Geographic Territory</label>
              <select
                className="w-full bg-[#050505] border border-white/10 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-[#00FFC2] font-mono"
                value={searchCountry}
                onChange={(e) => setSearchCountry(e.target.value)}
              >
                <option value="United States">United States</option>
                <option value="Canada">Canada</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="UAE">UAE</option>
                <option value="Australia">Australia</option>
                <option value="Europe">Europe</option>
              </select>
            </div>

            <div className="space-y-1 bg-[#030303] border border-white/5 p-3 rounded-xl flex flex-col justify-between">
              <label className="text-white/40 uppercase tracking-wider text-[10px] block font-semibold mb-1">3. Key Phrase / City search</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. London, Miami, Dublin, luxury, commercial"
                  className="flex-1 bg-[#050505] border border-white/10 rounded-lg px-2.5 py-1 text-white focus:outline-none focus:border-[#00FFC2]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button
                  type="submit"
                  disabled={isScraping}
                  className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans px-3.5 py-1 rounded-lg cursor-pointer font-bold transition flex items-center justify-center min-w-[70px]"
                >
                  {isScraping ? <RefreshCw className="animate-spin" size={14} /> : "Search"}
                </button>
              </div>
            </div>
          </form>

          {/* Scraped status indicator */}
          {scrapedStatus && (
            <div className="bg-white/5 border border-white/10 text-white/70 p-4 rounded-xl text-center flex items-center justify-center space-x-2 tracking-wide font-sans mt-3">
              <RefreshCw className="animate-spin text-[#00FFC2]" size={16} />
              <span>{scrapedStatus}</span>
            </div>
          )}

          {/* Scraped Leads Results Display List */}
          {discoveredLeads.length > 0 && (
            <div className="space-y-4 pt-3 border-t border-white/10">
              <div className="flex justify-between items-center bg-[#050505] px-3.5 py-2 rounded-lg border border-white/5">
                <span className="text-xs text-[#00FFC2] font-semibold flex items-center gap-1">
                  <Globe size={12} />
                  <span>Verified live businesses found via Google Search indexes:</span>
                </span>
                <span className="text-[10px] text-white/40 tracking-wider">SELECT TARGETS TO INGEST</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {discoveredLeads.map((dl, index) => {
                  const isAlreadyImported = importedIds.includes(dl.id);
                  return (
                    <div 
                      key={index} 
                      className={`p-4 bg-[#050505] border rounded-2xl space-y-3 shadow-inner flex flex-col justify-between transition-all duration-200 ${
                        isAlreadyImported ? "border-emerald-500/20 bg-emerald-950/5 opacity-70" : "border-white/10 hover:border-[#00FFC2]/30"
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] text-[#00FFC2] uppercase font-bold tracking-wider">{dl.industry.split(' ').slice(-2).join(' ')}</span>
                          <span className="text-[9px] text-white/40">{dl.country}</span>
                        </div>
                        <h4 className="font-sans font-bold text-white text-sm line-clamp-1">{dl.businessName}</h4>
                        <div className="space-y-1 text-[11px] text-white/60">
                          <p className="flex items-center space-x-1.5 font-sans">
                            <span className="text-white/40">URL:</span>
                            <span className="text-[#00FFC2] hover:underline font-mono truncate max-w-[140px]" title={dl.website}>{dl.website}</span>
                          </p>
                          <p className="flex items-center space-x-1.5">
                            <span className="text-white/40">Contact:</span>
                            <span className="font-serif italic text-white/80">{dl.ownerName}</span>
                          </p>
                          <p className="flex items-center space-x-1.5 font-mono text-[10px]">
                            <span className="text-white/40">Ph:</span>
                            <span>{dl.phone}</span>
                          </p>
                          <p className="text-[10px] font-mono leading-relaxed text-white/30 pt-1 border-t border-white/5 line-clamp-2" title={dl.notes}>
                            {dl.notes}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleImportLead(dl)}
                        disabled={isAlreadyImported}
                        className={`w-full py-1.5 rounded-lg text-[11px] font-sans font-bold transition flex items-center justify-center space-x-1 cursor-pointer ${
                          isAlreadyImported 
                            ? "bg-emerald-500/10 text-emerald-400 cursor-not-allowed border border-emerald-500/20" 
                            : "bg-white/5 hover:bg-white/10 text-white border border-white/10"
                        }`}
                      >
                        {isAlreadyImported ? (
                          <>
                            <Check size={12} className="text-emerald-400" />
                            <span>Prospect Ingested</span>
                          </>
                        ) : (
                          <>
                            <ArrowRight size={12} className="text-[#00FFC2]" />
                            <span>Ingest to CRM Database</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Slide down Logger Form */}
      {showAddForm && (
        <form onSubmit={handleAddNewLead} className="bg-[#0a0a0a] border border-white/10 p-5 rounded-2xl grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="md:col-span-3 border-b border-white/10 pb-2 mb-2 flex items-center justify-between">
            <span className="text-sm font-sans font-semibold text-white/90 flex items-center space-x-2">
              <HeartHandshake className="text-[#00FFC2]" size={16} />
              <span>Log Premium Target Lead Account</span>
            </span>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-white/40 hover:text-white cursor-pointer font-sans text-lg">&times;</button>
          </div>

          <div className="space-y-1">
            <label className="text-white/40 uppercase tracking-wider text-[10px]">Business Legal Entity</label>
            <input
              type="text"
              required
              placeholder="e.g. Apex Legal Firm Ltd"
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-white/40 uppercase tracking-wider text-[10px]">Owner / Director Representative</label>
            <input
              type="text"
              required
              placeholder="e.g. Robert Miller Esq"
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-white/40 uppercase tracking-wider text-[10px]">Primary Outreach Mailbox</label>
            <input
              type="email"
              required
              placeholder="e.g. rmiller@apexlegal.com"
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-white/40 uppercase tracking-wider text-[10px]">Direct Mobile Number</label>
            <input
              type="text"
              placeholder="e.g. +1 (310) 555-0192"
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-white/40 uppercase tracking-wider text-[10px]">Corporate Website URL</label>
            <input
              type="text"
              placeholder="e.g. apexlegal.com"
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <label className="text-white/40 uppercase tracking-wider text-[10px]">LinkedIn Custom Address</label>
            <input
              type="text"
              placeholder="e.g. linkedin.com/in/rmiller"
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
              value={linkedIn}
              onChange={(e) => setLinkedIn(e.target.value)}
            />
          </div>

          <div className="space-y-1 font-sans">
            <label className="text-white/40 font-mono uppercase tracking-wider text-[10px]">Industry Vertical</label>
            <select
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-[#00FFC2] font-mono"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
            >
              <option value="High-Ticket Real Estate Brokerages">High-Ticket Real Estate Brokerages</option>
              <option value="Premium Solar & CleanTech Installers">Premium Solar & CleanTech Installers</option>
              <option value="Personal Injury & Corporate Law Firms">Personal Injury & Corporate Law Firms</option>
              <option value="Specialized Orthodontic & Aesthetic Dental Clinics">Specialized Orthodontic & Aesthetic Dental Clinics</option>
              <option value="Enterprise SaaS & B2B Software Companies">Enterprise SaaS & B2B Software Companies</option>
            </select>
          </div>

          <div className="space-y-1 font-sans">
            <label className="text-white/40 font-mono uppercase tracking-wider text-[10px]">Territory HQ</label>
            <select
              className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-1 text-white focus:outline-none focus:border-[#00FFC2] font-mono"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
            >
              <option value="United States">United States</option>
              <option value="Canada">Canada</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="UAE">UAE</option>
              <option value="Australia">Australia</option>
              <option value="Europe">Europe</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-white/40 uppercase tracking-wider text-[10px] truncate block">Est. Revenue</label>
              <input
                type="text"
                className="w-full bg-[#050505] border border-white/10 rounded-lg px-2 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
                value={revenue}
                onChange={(e) => setRevenue(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <label className="text-white/40 uppercase tracking-wider text-[10px] truncate block">Employees</label>
              <input
                type="number"
                className="w-full bg-[#050505] border border-white/10 rounded-lg px-2 py-1.5 text-white focus:outline-none focus:border-[#00FFC2]"
                value={employees}
                onChange={(e) => setEmployees(Number(e.target.value))}
              />
            </div>
          </div>

          <div className="md:col-span-3 pt-2 text-right">
            <button
              type="submit"
              className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans px-5 py-2 rounded-lg cursor-pointer font-bold transition"
            >
              Add Prospect Records
            </button>
          </div>
        </form>
      )}

      {/* Leads Directory Table Card */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl overflow-hidden shadow-lg">
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-white font-sans font-medium text-base flex items-center space-x-2">
            <span>Leads CRM Pipelines</span>
            <span className="text-xs font-mono bg-white/5 text-white/50 px-2 py-0.5 rounded-full">{filteredLeads.length} total</span>
          </h3>
          <span className="text-xs text-white/40 font-mono">Select a target below to load in your active workbench panels</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-white/70">
            <thead>
              <tr className="bg-[#050505] border-b border-white/10 text-white/40 text-left uppercase tracking-wider text-[9px] font-mono">
                <th className="py-3.5 px-5">Business Legal Entity</th>
                <th className="py-3.5 px-4">Direct Contact Person</th>
                <th className="py-3.5 px-4">Niche Sector</th>
                <th className="py-3.5 px-4">HQ Territory</th>
                <th className="py-3.5 px-4">Annual Intake / Deal Size</th>
                <th className="py-3.5 px-4">Pipeline Status</th>
                <th className="py-3.5 px-5 text-center">Operation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredLeads.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-white/30">
                    <AlertCircle className="mx-auto text-white/20 mb-2 animate-pulse" size={24} />
                    <p className="font-sans text-sm font-semibold mb-1">No corporate leads match criteria.</p>
                    <p className="font-sans text-xs text-white/40 mb-3.5">Use the 'Smart Real-Client Finder' above to search the live web for actual operating businesses.</p>
                    <button
                      onClick={() => setShowScrapeForm(true)}
                      className="inline-flex items-center space-x-1.5 bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans font-bold px-3 py-1.5 rounded-lg text-xs cursor-pointer transition"
                    >
                      <Sparkles size={12} />
                      <span>Search Live Businesses</span>
                    </button>
                  </td>
                </tr>
              ) : (
                filteredLeads.map((l) => {
                  const isSelected = selectedLead?.id === l.id;
                  return (
                    <tr
                      key={l.id}
                      onClick={() => onSelectLead(l)}
                      className={`cursor-pointer transition duration-200 hover:bg-white/10 text-[11px] ${
                        isSelected ? 'bg-[#00FFC2]/5 border-l border-[#00FFC2]' : ''
                      }`}
                    >
                      <td className="py-4 px-5">
                        <div className="flex flex-col">
                           <span className="font-sans font-bold text-white text-[12px]">{l.businessName}</span>
                          <span className="text-[10px] text-white/40 hover:underline">{l.website}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex flex-col">
                          <span className="text-white/80 font-serif italic text-base [font-size:12px]">{l.ownerName}</span>
                          <span className="text-[10px] text-white/40">{l.email}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 font-sans text-white/50">
                        <span className="truncate block max-w-[180px]" title={l.industry}>{l.industry}</span>
                      </td>
                      <td className="py-4 px-5 flex items-center space-x-1 font-sans text-white/50 h-10 border-none">
                        <MapPin size={10} className="text-[#00FFC2]" />
                        <span>{l.country}</span>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex flex-col">
                          <span className="text-white text-[11px] font-semibold">{l.revenueEstimate}</span>
                          <span className="text-[10px] text-[#00FFC2]">Deal: ${(l.dealSize ?? 12000).toLocaleString()} USD</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 font-sans font-semibold rounded text-[10px] uppercase border ${
                          l.status === 'Closed Won' ? 'bg-[#00FFC2]/15 text-[#00FFC2] border-[#00FFC2]/30' :
                          l.status === 'Meeting Booked' ? 'bg-purple-500/10 text-purple-300 border-purple-500/20' :
                          l.status === 'Proposal Sent' ? 'bg-[#00FFC2]/5 text-[#00FFC2] border-white/5' :
                          l.status === 'Audited' ? 'bg-white/5 text-white/80 border-white/10' :
                          l.status === 'Contacted' ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20' :
                          'bg-white/5 text-white/40 border-white/10'
                        }`}>
                          {l.status}
                        </span>
                      </td>
                      <td className="py-3 px-5 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectLead(l);
                            }}
                            className="bg-white/5 border border-white/10 text-white hover:bg-white/10 px-2.5 py-1 rounded transition text-[10px] font-sans font-medium cursor-pointer"
                          >
                            Mount Work
                          </button>
                          {onDeleteLead && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteLead(l.id);
                              }}
                              title="Delete Lead"
                              className="p-1 px-1.5 border border-white/10 rounded bg-[#1a0a0a] hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 transition cursor-pointer"
                            >
                              <Trash2 size={12} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
