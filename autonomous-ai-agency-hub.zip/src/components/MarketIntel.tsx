import React, { useState } from 'react';
import { Search, Sparkles, TrendingUp, HelpCircle, ArrowUpRight, Zap, Target, RefreshCw } from 'lucide-react';
import { IndustryOpportunity } from '../types';
import { secureFetch } from '../lib/api';

interface MarketIntelProps {
  opportunities: IndustryOpportunity[];
  onAddOpportunities: (newOpps: IndustryOpportunity[]) => void;
}

export default function MarketIntel({ opportunities, onAddOpportunities }: MarketIntelProps) {
  const [geoTarget, setGeoTarget] = useState('United States');
  const [customFocus, setCustomFocus] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Handle live market analysis using server-side Gemini API
  const handleMarketDiscovery = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    setErrorMsg('');

    try {
      const res = await secureFetch('/api/agency/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          country: geoTarget,
          customFocus: customFocus || 'High ticket services requiring lead qualification client automation'
        })
      });

      if (!res.ok) {
        throw new Error('Server returned error response');
      }

      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        onAddOpportunities(data);
        setCustomFocus('');
      } else {
        throw new Error('Invalid response structure received');
      }
    } catch (err: any) {
      setErrorMsg('Discovery failed. Operating under mock parameters: ' + err.message);
      // Fail gracefully and create a highly customized simulation opportunity fallback
      const fallbackOpps: IndustryOpportunity[] = [
        {
          industry: customFocus || "Premium Landscape & Outdoor Architects",
          opportunityScore: Math.floor(Math.random() * 15) + 80,
          avgContractValue: 14500,
          estCloseRate: 16,
          demandCategory: "High",
          manualWorkWaste: "Manually measuring backyard scale plans, lengthy design iteration cycles with cold residential buyers, and phone reservation delays.",
          reasoning: "Landscape engineers lose valuable weekend slots playing client phone-tag. Deploying immediate pre-qualifiers recovers lost booking revenue."
        }
      ];
      onAddOpportunities(fallbackOpps);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Visual Banner */}
      <div className="bg-gradient-to-br from-[#0c0c0c] to-[#070707] border border-white/10 rounded-2xl p-6 relative overflow-hidden">
        <div className="max-w-2xl relative z-10">
          <div className="inline-flex items-center space-x-2 bg-[#00FFC2]/5 text-[#00FFC2] px-3 py-1 border border-[#00FFC2]/20 rounded-full text-xs font-mono font-medium mb-3">
            <Zap size={12} className="animate-pulse" />
            <span>Phases 1 & 11 — Autonomic Lead Research</span>
          </div>
          <h2 className="text-3xl font-serif text-white tracking-tight leading-tight">System Market Analyst Core</h2>
          <p className="text-white/60 text-sm mt-2 font-sans leading-relaxed">
            Targeting elite service providers with average deal closures ranging from <span className="text-[#00FFC2] font-semibold font-mono">$3,000 to $20,000+</span>, maximizing client return-on-investment out of manual operational leaks.
          </p>
        </div>
        <div className="absolute top-0 right-0 h-48 w-48 bg-[#00FFC2]/3 rounded-full blur-3xl"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Research Discovery Form */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4">
          <div className="flex items-center space-x-2 border-b border-white/10 pb-3">
            <Target className="text-[#00FFC2]" size={18} />
            <span className="font-sans font-medium text-white/90">Trigger Custom Intelligence Scrapes</span>
          </div>

          <form onSubmit={handleMarketDiscovery} className="space-y-4 text-xs font-mono text-white/70">
            {/* Geo Selector */}
            <div className="space-y-2">
              <label className="text-white/40 block uppercase tracking-wider text-[10px]">Geographic Targeting</label>
              <select
                className="w-full bg-[#050505] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#00FFC2] font-mono"
                value={geoTarget}
                onChange={(e) => setGeoTarget(e.target.value)}
              >
                <option value="United States">United States (L.A., NY, Luxury focus)</option>
                <option value="United Kingdom">United Kingdom (London Premium Services)</option>
                <option value="UAE">UAE (Dubai Construction & Aesthetic Medicine)</option>
                <option value="Canada">Canada (Toronto, Vancouver Builders)</option>
                <option value="Australia">Australia (Sydney/Melbourne Premium Legal)</option>
                <option value="Europe">Continental Europe (MedTech & Enterprise)</option>
              </select>
            </div>

            {/* Custom Focus Prompt */}
            <div className="space-y-2 font-sans">
              <label className="text-white/40 block font-mono uppercase tracking-wider text-[10px]">Strategic Concept / Niche</label>
              <textarea
                placeholder="e.g. Cosmetic surgery clinics in Dubai, custom HVAC contractors in Texas..."
                className="w-full h-24 bg-[#050505] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#00FFC2] font-mono text-xs leading-relaxed"
                value={customFocus}
                onChange={(e) => setCustomFocus(e.target.value)}
              />
            </div>

            {errorMsg && (
              <p className="text-amber-400 text-[10px] leading-relaxed bg-amber-500/5 border border-amber-500/10 p-2.5 rounded-lg font-sans">
                {errorMsg}
              </p>
            )}

            <button
              type="submit"
              disabled={isSearching}
              className="w-full bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-semibold py-2.5 px-4 rounded-lg flex items-center justify-center space-x-2 transition-all duration-300 font-sans cursor-pointer text-sm"
            >
              {isSearching ? (
                <>
                  <RefreshCw className="animate-spin text-black" size={16} />
                  <span>Gathering Live Intent Data...</span>
                </>
              ) : (
                <>
                  <Sparkles size={16} className="text-black" />
                  <span>Discover Opportunities</span>
                </>
              )}
            </button>
          </form>

          <div className="bg-[#050505] border border-white/15 rounded-xl p-3 text-[11px] text-white/50 space-y-2 leading-relaxed">
            <span className="text-[#00FFC2] font-semibold font-mono uppercase block text-[10px]">Scrape Sources Connected:</span>
            <ul className="list-disc leading-4 pl-4 space-y-1 font-mono text-white/40 text-[10px]">
              <li>Google Maps Places API</li>
              <li>Apollo Directory Hook</li>
              <li>LinkedIn Public Directories</li>
              <li>Crunchbase Metadata Records</li>
            </ul>
          </div>
        </div>

        {/* Opportunities List Grid */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-sans font-medium text-lg flex items-center space-x-2">
              <span>Opportunities Scoped</span>
              <span className="text-xs font-mono bg-white/10 text-white/80 px-2.5 py-0.5 rounded-full">{opportunities.length}</span>
            </h3>
            <span className="text-xs text-white/40 font-mono">Priority Ranked</span>
          </div>

          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
            {opportunities
              .sort((a, b) => b.opportunityScore - a.opportunityScore)
              .map((opp, idx) => (
                <div
                  key={idx}
                  className="bg-[#0a0a0a] border border-white/10 hover:border-white/20 rounded-xl p-5 transition-all duration-300 shadow-sm"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-white/5 pb-3 mb-3">
                    <div className="flex items-center space-x-3">
                      <span className="text-xs font-mono font-semibold bg-[#00FFC2]/5 text-[#00FFC2] h-6 w-6 flex items-center justify-center rounded-md border border-[#00FFC2]/20">
                        {idx + 1}
                      </span>
                      <h4 className="text-white font-sans font-semibold text-base">{opp.industry}</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                        opp.demandCategory === 'High' 
                          ? 'bg-[#00FFC2]/5 text-[#00FFC2] border-[#00FFC2]/20' 
                          : 'bg-amber-500/5 text-amber-400 border-amber-500/20'
                      }`}>
                        {opp.demandCategory} Demand
                      </span>
                      <div className="text-right">
                        <span className="text-xs text-white/40 font-mono">Score: </span>
                        <span className="text-sm font-bold font-mono text-[#00FFC2]">{opp.opportunityScore}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-[13px] text-white/80 leading-relaxed italic border-l-2 border-[#00FFC2]/30 pl-3 mb-3 font-serif">
                    "{opp.reasoning}"
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                    {/* Contract Details */}
                    <div className="bg-[#050505] rounded-lg p-3 space-y-1.5 border border-white/5">
                      <div className="flex justify-between text-[11px] text-white/50">
                        <span>AVERAGE DEAL VALUE:</span>
                        <span className="text-white font-semibold">${opp.avgContractValue.toLocaleString()} / setup</span>
                      </div>
                      <div className="flex justify-between text-[11px] text-white/50">
                        <span>EST. WEAK FOLLOWUP CLOSES:</span>
                        <span className="text-[#00FFC2] font-semibold">{opp.estCloseRate}% Opportunity</span>
                      </div>
                    </div>

                    {/* Operational Leakages */}
                    <div className="bg-[#050505] rounded-lg p-3 space-y-1.5 flex flex-col justify-center border border-white/5">
                      <span className="text-[10px] uppercase tracking-wider font-semibold text-[#00FFC2] flex items-center space-x-1 font-mono">
                        <TrendingUp size={12} />
                        <span>Critical Financial Leaks Found:</span>
                      </span>
                      <p className="text-[11px] text-white/50 leading-relaxed font-sans truncate" title={opp.manualWorkWaste}>
                        {opp.manualWorkWaste}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
