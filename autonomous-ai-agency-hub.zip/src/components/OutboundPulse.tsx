import React from 'react';
import { initialCampaigns } from '../data';
import { OutboundCampaign } from '../types';
import { Mail, CheckCircle, TrendingUp, RefreshCw, BarChart2, Activity, Play, Pause, Code } from 'lucide-react';

interface OutboundPulseProps {
  campaigns: OutboundCampaign[];
  onToggleStatus: (campId: string) => void;
}

export default function OutboundPulse({ campaigns, onToggleStatus }: OutboundPulseProps) {
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Analytics Ticker Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex items-center space-x-4 relative overflow-hidden font-mono text-xs">
          <div className="p-3 bg-white/5 text-[#00FFC2] rounded-xl border border-white/10">
            <Mail size={18} />
          </div>
          <div>
            <span className="text-[10px] text-white/40 uppercase tracking-widest block font-sans font-semibold">Absolute Despatches</span>
            <span className="text-xl font-bold font-sans text-white block mt-0.5">867 leads</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex items-center space-x-4 relative overflow-hidden font-mono text-xs">
          <div className="p-3 bg-white/5 text-[#00FFC2] rounded-xl border border-white/10">
            <BarChart2 size={18} />
          </div>
          <div>
            <span className="text-[10px] text-white/40 uppercase tracking-widest block font-sans font-semibold">Unification Open Metrics</span>
            <span className="text-xl font-bold font-sans text-white block mt-0.5">68.5% average</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex items-center space-x-4 relative overflow-hidden font-mono text-xs">
          <div className="p-3 bg-white/5 text-[#00FFC2] rounded-xl border border-white/10">
            <Activity size={18} />
          </div>
          <div>
            <span className="text-[10px] text-white/40 uppercase tracking-widest block font-sans font-semibold">Incoming Positive Replies</span>
            <span className="text-xl font-bold font-sans text-white block mt-0.5">10.1% average</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex items-center space-x-4 relative overflow-hidden font-mono text-xs">
          <div className="p-3 bg-[#00FFC2]/10 text-[#00FFC2] rounded-xl border border-[#00FFC2]/20">
            <CheckCircle size={18} />
          </div>
          <div>
            <span className="text-[10px] text-white/40 uppercase tracking-widest block font-sans font-semibold">System Booked Meetings</span>
            <span className="text-xl font-bold font-sans text-[#00FFC2] block mt-0.5">21 corporate</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Campaign Monitor Table */}
        <div className="lg:col-span-2 bg-[#0a0a0a] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
          <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
            <h3 className="text-white font-sans font-semibold text-base">Campaign Outbound Pulse</h3>
            <span className="text-xs text-white/40 font-mono">Real-time Sandbox Stat-line</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-white/70">
              <thead>
                <tr className="bg-[#050505] border-b border-white/10 text-white/40 text-left uppercase tracking-wider text-[9px]">
                  <th className="py-3 px-5">Active Target Subject Niche</th>
                  <th className="py-3 px-4">Contact Size</th>
                  <th className="py-3 px-4">Opens / Replies</th>
                  <th className="py-3 px-4">Bookings Ratio</th>
                  <th className="py-3 px-4">A/B Stack</th>
                  <th className="py-3 px-5 text-right">Status Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {campaigns.map((camp) => (
                  <tr key={camp.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-4 px-5">
                      <div className="flex flex-col">
                        <span className="font-sans font-bold text-white text-[11px] leading-relaxed">{camp.name}</span>
                        <span className="text-[10px] text-white/40 truncate max-w-[200px]" title={camp.subject}>"{camp.subject}"</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-white font-bold">{camp.sent} / {camp.totalLeads}</td>
                    <td className="py-4 px-4 text-white/60">
                      <div>Opens: {camp.opens} ({(camp.opens / (camp.sent || 1) * 100).toFixed(0)}%)</div>
                      <div className="text-[10px] text-[#00FFC2]">Replies: {camp.replies} ({(camp.replies / (camp.sent || 1) * 100).toFixed(1)}%)</div>
                    </td>
                    <td className="py-4 px-4 font-sans font-semibold text-white">
                      <span className="text-[#00FFC2] font-mono">{camp.meetingsBooked} Booked</span>
                      <div className="text-[10px] text-white/40">{(camp.meetingsBooked / (camp.sent || 1) * 100).toFixed(1)}% Conv</div>
                    </td>
                    <td className="py-4 px-4 text-white/40 text-[10px] truncate max-w-[100px]">{camp.abTestVersion}</td>
                    <td className="py-4 px-5 text-right font-sans">
                      <button
                        onClick={() => onToggleStatus(camp.id)}
                        className={`px-3 py-1.5 rounded text-[10px] font-bold transition cursor-pointer inline-flex items-center space-x-1 ${
                          camp.status === 'Active'
                            ? 'bg-rose-500/10 border border-rose-500/20 text-rose-450 hover:bg-rose-500/20'
                            : 'bg-[#00FFC2]/15 border border-[#00FFC2]/30 text-[#00FFC2] hover:bg-[#00FFC2]/20'
                        }`}
                      >
                        {camp.status === 'Active' ? (
                          <>
                            <Pause size={10} />
                            <span>Pause Sequence</span>
                          </>
                        ) : (
                          <>
                            <Play size={10} className="text-black" />
                            <span>Dispatch Active</span>
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Self Optimization Engine (Phase 11) */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4 font-sans shadow-2xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <span className="font-semibold text-white text-sm flex items-center space-x-1.5">
              <RefreshCw className="text-[#00FFC2] shrink-0" size={16} />
              <span>AI Self-Refinement Engine</span>
            </span>
            <span className="font-mono text-[9px] bg-[#00FFC2]/15 text-[#00FFC2] px-2 py-0.5 rounded uppercase font-bold border border-[#00FFC2]/20">Active Loop</span>
          </div>

          <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1">
            {/* Optimization Step 1 */}
            <div className="bg-[#050505] border border-white/5 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between items-center font-mono">
                <span className="text-[#00FFC2] font-bold uppercase tracking-wider text-[9px]">A/B Opt Record - real estate</span>
                <span className="text-white/30 text-[9px]">Verified May 29</span>
              </div>
              <p className="text-white/80 text-[11px] font-medium leading-relaxed font-sans">
                Replaced traditional "Hi (Name)" greeting with a direct friction diagnosis ("Quick logic inquiry on L.A. latencies").
              </p>
              <div className="flex justify-between text-[10px] text-white/40 font-mono bg-[#0a0a0a] border border-white/5 p-2 rounded">
                <span>REPLY RATE IMPROVEMENT:</span>
                <span className="text-[#00FFC2] font-bold font-sans text-[11px] leading-none">+3.2% ratio boost</span>
              </div>
            </div>

            {/* Optimization Step 2 */}
            <div className="bg-[#050505] border border-white/5 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between items-center font-mono">
                <span className="text-[#00FFC2] font-bold uppercase tracking-wider text-[9px]">A/B Opt Record - specialized law</span>
                <span className="text-white/30 text-[9px]">Verified May 27</span>
              </div>
              <p className="text-white/80 text-[11px] font-medium leading-relaxed font-sans">
                Shifted pricing pitch in Cold Email from "$4,500 retainer model" directly to "unlocked lost-revenue projection modeling".
              </p>
              <div className="flex justify-between text-[10px] text-white/40 font-mono bg-[#0a0a0a] border border-white/5 p-2 rounded">
                <span>CONVERSION RATE BOOST:</span>
                <span className="text-[#00FFC2] font-bold font-sans text-[11px] leading-none">+5.8% appointment booking</span>
              </div>
            </div>

            {/* Optimization Step 3 */}
            <div className="bg-[#050505] border border-white/5 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex justify-between items-center font-mono">
                <span className="text-white/50 font-bold uppercase tracking-wider text-[9px]">Autonomous System Audit</span>
                <span className="text-white/30 text-[9px]">Continuous Sweep</span>
              </div>
              <p className="text-white/40 text-[11px] leading-relaxed font-sans">
                Our operations monitor sweeps public Apollo directories daily. Removed 12 non-responsive targets with missing SSL certs from campaign loops to protect mailing domain spam scores.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
