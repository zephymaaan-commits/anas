import React, { useState } from 'react';
import { FileText, Sparkles, AlertCircle, RefreshCw, Copy, Check, Download, ShieldAlert, Award, Loader2 } from 'lucide-react';
import { Lead } from '../types';
import { secureFetch } from '../lib/api';

interface ProposalRoomProps {
  selectedLead: Lead | null;
  onUpdateStatus: (leadId: string, status: Lead['status']) => void;
  onRecordMobilizationTransaction: (leadId: string, amount: number, desc: string, method: 'Stripe' | 'Wise' | 'PayPal') => void;
}

export default function ProposalRoom({ selectedLead, onUpdateStatus, onRecordMobilizationTransaction }: ProposalRoomProps) {
  const [offerType, setOfferType] = useState<'setup' | 'hybrid' | 'performance'>('hybrid');
  const [setupFee, setSetupFee] = useState(4500);
  const [monthlyRetainer, setMonthlyRetainer] = useState(2500);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Custom outputs states
  const [closingStrategy, setClosingStrategy] = useState('');
  const [proposalDoc, setProposalDoc] = useState('');
  const [copiedContract, setCopiedContract] = useState(false);
  const [sentNotice, setSentNotice] = useState('');
  const [isSending, setIsSending] = useState(false);

  // Trigger Gemini / Fallback synthesis
  const handleGenerateProposal = async () => {
    if (!selectedLead) return;
    setIsGenerating(true);
    setSentNotice('');

    const formattedPricing = offerType === 'hybrid'
      ? `$${setupFee.toLocaleString()} Setup + $${monthlyRetainer.toLocaleString()}/month Retainer`
      : offerType === 'setup'
      ? `$${setupFee.toLocaleString()} Flat Setup Package`
      : `Performance Based Model: $1,500 Mobilization + 15% Qualified Sales Closing Commission`;

    try {
      const response = await secureFetch('/api/agency/proposal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead: selectedLead,
          offerType,
          pricing: formattedPricing
        })
      });

      if (!response.ok) {
        throw new Error('Agreement desk error');
      }

      const results = await response.json();
      setClosingStrategy(results.closingStrategy);
      setProposalDoc(results.proposalDoc);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyProposalMarkdown = () => {
    navigator.clipboard.writeText(proposalDoc);
    setCopiedContract(true);
    setTimeout(() => setCopiedContract(false), 2000);
  };

  const handleDispatchProposalToClient = () => {
    if (!selectedLead) return;
    setIsSending(true);

    setTimeout(() => {
      onUpdateStatus(selectedLead.id, 'Proposal Sent');
      
      // Calculate upfront 25% mobilization fee
      const upfrontAmount = offerType === 'hybrid' || offerType === 'setup' 
        ? Math.round(setupFee * 0.25)
        : 1500; // default mobilization for performance

      onRecordMobilizationTransaction(
        selectedLead.id, 
        upfrontAmount, 
        `25% Front-end Mobilization Security Deposit (${selectedLead.businessName})`,
        'Stripe'
      );

      setIsSending(false);
      setSentNotice(`Capital Proposal and onboarding request dispatched to Charles Sterling (${selectedLead.email}). Marked status as 'Proposal Sent' in CRM, and recorded pending Stripe billing invoice!`);
    }, 1500);
  };

  if (!selectedLead) {
    return (
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-12 text-center text-white/50 font-sans pb-16 animate-fadeIn">
        <FileText size={32} className="text-[#00FFC2] mx-auto mb-3 animate-pulse" />
        <h3 className="font-sans font-semibold text-white text-lg">Proposal Room Offline</h3>
        <p className="text-xs max-w-sm mx-auto mt-2 leading-relaxed text-white/40">
          Make sure to select or enter a target business account within the <span className="font-semibold text-[#00FFC2]">Leads CRM Database</span> to structure closing packages.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Structural Options Panel */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-5 font-mono text-xs shadow-2xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-white/10 pb-3 gap-2">
          <span className="font-sans font-semibold text-white text-sm flex items-center space-x-1.5">
            <Award className="text-[#00FFC2]" size={16} />
            <span>Structure Deal Framework (Phases 7 & 8)</span>
          </span>
          <span className="text-[10px] text-white/40 font-semibold font-mono tracking-wider">Tailoring for: {selectedLead.businessName}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Offer Type */}
          <div className="space-y-2 font-sans">
            <label className="text-white/40 font-mono text-[10px] block uppercase font-bold tracking-wider">Pricing Model Selector</label>
            <div className="grid grid-cols-3 gap-1 bg-[#050505] p-1 rounded-lg border border-white/10">
              <button
                type="button"
                onClick={() => setOfferType('setup')}
                className={`text-[10px] py-1.5 rounded transition font-bold cursor-pointer ${offerType === 'setup' ? 'bg-[#00FFC2] text-black font-extrabold shadow-lg' : 'text-white/40 hover:text-white'}`}
              >
                Fixed Setup
              </button>
              <button
                type="button"
                onClick={() => setOfferType('hybrid')}
                className={`text-[10px] py-1.5 rounded transition font-bold cursor-pointer ${offerType === 'hybrid' ? 'bg-[#00FFC2] text-black font-extrabold shadow-lg' : 'text-white/40 hover:text-white'}`}
              >
                Hybrid Ret
              </button>
              <button
                type="button"
                onClick={() => setOfferType('performance')}
                className={`text-[10px] py-1.5 rounded transition font-bold cursor-pointer ${offerType === 'performance' ? 'bg-[#00FFC2] text-black font-extrabold shadow-lg' : 'text-white/40 hover:text-white'}`}
              >
                Comm Model
              </button>
            </div>
          </div>

          {/* Pricing range 1 */}
          {(offerType === 'hybrid' || offerType === 'setup') && (
            <div className="space-y-2">
              <label className="text-white/50 uppercase tracking-widest text-[9px] font-bold block font-sans">Implementation Setup Premium ($4,500 Base)</label>
              <input
                type="range"
                min="3000"
                max="20000"
                step="500"
                className="w-full h-1 bg-[#050505] rounded-lg appearance-none cursor-pointer accent-[#00FFC2]"
                value={setupFee}
                onChange={(e) => setSetupFee(Number(e.target.value))}
              />
              <div className="flex justify-between text-[11px] font-sans text-white/50 font-bold mt-1">
                <span className="text-white/30 font-mono text-[9px]">$3k base</span>
                <span className="text-[#00FFC2] font-mono">Setup: ${setupFee.toLocaleString()} USD</span>
              </div>
            </div>
          )}

          {/* Pricing range 2 */}
          {offerType === 'hybrid' && (
            <div className="space-y-2">
              <label className="text-white/50 uppercase tracking-widest text-[9px] font-bold block font-sans">Autonomous Service Retainer ($2,500/mo Base)</label>
              <input
                type="range"
                min="1000"
                max="10000"
                step="250"
                className="w-full h-1 bg-[#050505] rounded-lg appearance-none cursor-pointer accent-[#00FFC2]"
                value={monthlyRetainer}
                onChange={(e) => setMonthlyRetainer(Number(e.target.value))}
              />
              <div className="flex justify-between text-[11px] font-sans text-white/50 font-bold mt-1">
                <span className="text-white/30 font-mono text-[9px]">$1k limit</span>
                <span className="text-[#00FFC2] font-mono">Retainer: ${monthlyRetainer.toLocaleString()}/mo</span>
              </div>
            </div>
          )}

          {/* Performance fallback notes */}
          {offerType === 'performance' && (
            <div className="md:col-span-2 bg-[#050505] p-3.5 rounded-xl border border-white/5 flex items-center space-x-3 text-white/50 text-[11px] leading-relaxed">
              <AlertCircle className="text-[#00FFC2] shrink-0" size={16} />
              <p className="font-sans">
                Performance frameworks charge an upfront <span className="text-white font-semibold">$1,500 setup deposit</span> to coordinate Twilio API pipelines. Ongoing profits are settled on a 15% dynamic revenue share per lead closed.
              </p>
            </div>
          )}
        </div>

        <div className="pt-2 text-right">
          <button
            onClick={handleGenerateProposal}
            disabled={isGenerating}
            className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black px-5 py-2.5 rounded-lg flex items-center space-x-2 font-sans font-bold cursor-pointer shadow-lg transition duration-200 ml-auto"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="animate-spin text-black" size={14} />
                <span>Designing custom terms agreement...</span>
              </>
            ) : (
              <>
                <Sparkles size={14} className="text-black" />
                <span>Compile High-Ticket Agreement Document</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Render Outputs splits */}
      {proposalDoc ? (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 animate-fadeIn">
          {/* Strategy Battle Card column */}
          <div className="lg:col-span-2 bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4 font-sans text-xs shadow-2xl">
            <h4 className="font-sans font-semibold text-white/90 border-b border-white/10 pb-2 text-sm">Strategic Close Battle-Card</h4>
            
            <div className="max-h-[380px] overflow-y-auto pr-1">
              <div className="bg-[#050505] border border-white/5 rounded-xl p-4 font-mono text-[11px] leading-relaxed space-y-3 prose prose-invert">
                {/* Parse Markdown representation */}
                <div className="whitespace-pre-wrap text-white/80">
                  {closingStrategy}
                </div>
              </div>
            </div>

            <div className="bg-[#050505] border border-white/5 rounded-xl p-3 text-[10px] font-mono text-white/40 flex items-center space-x-2 leading-relaxed">
              <ShieldAlert className="text-amber-500 shrink-0" size={16} />
              <p>HIPAA/GDPR security, data-latency and compliance arguments pre-mapped directly within objection notes.</p>
            </div>
          </div>

          {/* Proposal contract Document workspace */}
          <div className="lg:col-span-3 space-y-4">
            <div className="flex justify-between items-center text-xs">
              <span className="text-white/40 font-mono uppercase tracking-wider font-semibold">Formal Proposal Document Agreement</span>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={copyProposalMarkdown}
                  className="bg-[#050505] border border-white/10 text-white/50 hover:text-white px-3 py-1.5 rounded-lg font-mono text-[10px] flex items-center space-x-1.5 cursor-pointer transition-colors"
                >
                  {copiedContract ? (
                    <>
                      <Check size={12} className="text-[#00FFC2]" />
                      <span className="text-[#00FFC2] font-semibold">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy size={12} />
                      <span>Copy MD Code</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleDispatchProposalToClient}
                  disabled={isSending}
                  className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans font-bold px-4 py-1.5 rounded-lg flex items-center space-x-1.5 cursor-pointer shadow transition"
                >
                  {isSending ? (
                    <Loader2 className="animate-spin text-black" size={12} />
                  ) : (
                    <span>Dispatch Proposal</span>
                  )}
                </button>
              </div>
            </div>

            <div className="bg-[#050505] border border-white/10 rounded-2xl p-6 min-h-[380px] prose prose-invert overflow-y-auto max-h-[460px] shadow-inner">
              <div className="whitespace-pre-wrap text-white/90 leading-relaxed font-mono text-[11px]">
                {proposalDoc}
              </div>
            </div>

            {sentNotice && (
              <div className="bg-[#00FFC2]/10 border border-[#00FFC2]/20 p-4 rounded-xl text-xs text-[#00FFC2] font-mono leading-relaxed animate-scaleIn">
                {sentNotice}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-[#050505] border border-white/10 rounded-2xl p-10 text-center space-y-4 pb-12 shadow-2xl">
          <FileText size={32} className="text-[#00FFC2] mx-auto animate-pulse" />
          <h3 className="font-sans font-medium text-white text-base">Legal Contracts Engine Idle</h3>
          <p className="text-white/40 max-w-sm mx-auto text-xs leading-relaxed">
            Click 'Compile High-Ticket Agreement Document' to instruct the strategic helper to outline milestones, warranties, and prices automatically.
          </p>
        </div>
      )}
    </div>
  );
}
