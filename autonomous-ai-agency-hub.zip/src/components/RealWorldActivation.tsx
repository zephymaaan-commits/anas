import React, { useState } from 'react';
import { Lead } from '../types';
import { 
  ShieldCheck, 
  Mail, 
  ExternalLink, 
  Building, 
  Send, 
  CreditCard, 
  Sparkles, 
  CheckCircle2, 
  Compass, 
  HelpCircle, 
  Lock,
  Globe
} from 'lucide-react';
import { auth, googleProvider, signInWithPopup } from '../lib/firebase';
import { GoogleAuthProvider } from 'firebase/auth';

interface RealWorldActivationProps {
  leads: Lead[];
  gmailToken: string | null;
  gmailProfile: { email?: string; name?: string; picture?: string; } | null;
  onDisconnectGmail: () => void;
  onConnectGmail: (token: string, profile: { email?: string; name?: string; picture?: string }) => void;
}

export default function RealWorldActivation({ 
  leads,
  gmailToken,
  gmailProfile,
  onDisconnectGmail,
  onConnectGmail
}: RealWorldActivationProps) {
  // Configured Keys states
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [stripePublishable, setStripePublishable] = useState('');
  const [stripeSecret, setStripeSecret] = useState('');
  const [supportEmail, setSupportEmail] = useState('anasshaik167@gmail.com');
  const [isSaved, setIsSaved] = useState(false);

  // Outbox Lead Selection
  const realScrapedLeads = leads.filter(l => l.email && l.website);
  const [selectedLeadId, setSelectedLeadId] = useState(realScrapedLeads[0]?.id || '');
  const selectedLead = leads.find(l => l.id === selectedLeadId);

  // Payout information
  const userBankAccount = "Canara Bank (A/C: 1622101026993, IFSC: CNR0001622)";

  // Handle saving API key state simulator
  const handleSaveConfigs = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
    }, 3000);
  };

  // Build the mailto link details based on chosen lead and its audit findings
  const getMailtoLink = () => {
    if (!selectedLead) return '#';
    const email = selectedLead.email;
    const subject = `Question regarding delayed response flows on ${selectedLead.website}`;
    
    // Customize pitch dynamically
    const owner = selectedLead.ownerName || "there";
    const biz = selectedLead.businessName;
    const industry = selectedLead.industry;
    const revenueOpportunity = selectedLead.audit?.revenueOpportunity ?? `revering 15+ lost premium high-ticket client inquiries annually.`;
    const lostRev = selectedLead.audit?.estimatedRevenueLost ?? (selectedLead.dealSize ? selectedLead.dealSize * 8 : 120000);
    
    const emailBody = `Hi ${owner},

I was looking closely at your operational structure at ${biz}. 

I noticed that your website contact and inquiry flows on ${selectedLead.website} currently require manual triage and have response delays of up to several hours. For most ${industry} companies, this delay leads to an immediate 25-35% drop-off rate as clients leave for faster competitors.

At your contract sizes, this latency is leaking an estimated $${lostRev.toLocaleString()} USD in annualized revenue opportunity.

We build low-overhead automated intake pipelines specifically for the web. Our system triggers a pre-screening automated SMS or phone callback in under 45 seconds to qualify the lead and sync them directly to your calendar or CRM system automatically.

I prepared a quick 3-minute visual mock of how this fits into your database.

Would you be open to a quick call next Tuesday at 2:00 PM to review the breakdown?

Best regards,
Autonomous Operations Suite
Contact: ${supportEmail}`;

    return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`;
  };

  return (
    <div className="space-y-6 animate-fadeIn font-sans">
      
      {/* Visual Header Banner */}
      <div className="bg-gradient-to-r from-[#00FFC2]/10 via-slate-900 to-black border border-[#00FFC2]/20 rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#00FFC2]/5 rounded-full filter blur-2xl pointer-events-none"></div>
        
        <div className="relative z-10 space-y-2.5">
          <div className="flex items-center space-x-2 text-[10px] text-[#00FFC2] font-mono tracking-widest uppercase font-semibold">
            <Sparkles size={12} className="animate-spin-slow text-[#00FFC2]" />
            <span>Operational Reality Activation</span>
          </div>
          <h2 className="text-white text-xl lg:text-2xl font-bold tracking-tight">
            How to Turn AXON.operator Into a Real, Money-Making Business ⚡
          </h2>
          <p className="text-white/70 text-xs lg:text-sm max-w-3xl leading-relaxed">
            Currently, your workspace operates in a **high-fidelity sandbox** so you can safely configure calendars, practice objection handling with AI bots, and generate sales audits. But this platform is a real, functional workstation designed for you to search, pitch, sign, and invoice **real high-ticket clients** who will transfer physical money to your <strong>Canara Bank Account</strong>.
          </p>
        </div>
      </div>

      {/* Direct App Download & Native Installation Hub */}
      <div className="bg-[#0b0c10] border-2 border-[#00FFC2]/40 rounded-2xl p-6 space-y-4 shadow-[0_0_20px_rgba(0,255,194,0.15)] font-sans">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-[#00FFC2]/10 text-[#00FFC2] rounded-xl border border-[#00FFC2]/20">
              <Globe size={18} />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-[#00FFC2] tracking-wider font-bold">📲 DIRECT NATIVE INSTALLATION & RUN TIME GUIDE</span>
              <h3 className="text-sm font-bold text-white mt-0.5">Run as a Real, Fullscreen Mobile & Desktop Application</h3>
            </div>
          </div>
          <span className="text-[9px] font-mono px-2.5 py-1 text-black bg-[#00FFC2] rounded-full uppercase font-bold animate-pulse">
            Ready to Install
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Column 1: Direct Live Web App URL */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-2.5 flex flex-col justify-between">
            <div className="space-y-1.5">
              <span className="text-[10px] font-mono text-teal-400 block tracking-wider uppercase font-bold">🌐 1. Live Instant Preview (No Installer Needed)</span>
              <p className="text-white/80 text-[11px] leading-relaxed">
                Your app is already fully compiled and running on high-speed servers. You don't have to download anything or deal with complex installations! You can load it instantly in any browser.
              </p>
            </div>
            <div className="pt-2">
              <a 
                href="https://ais-pre-3xwqzag5pvmfmrm6hf2c7h-470436995098.asia-east1.run.app" 
                target="_blank" 
                rel="noreferrer" 
                className="w-full bg-[#00FFC2]/10 hover:bg-[#00FFC2]/15 border border-[#00FFC2]/30 text-[#00FFC2] px-3 py-2 rounded-xl text-xs font-bold text-center block transition cursor-pointer"
              >
                Open Direct Fullsite Link ↗
              </a>
            </div>
          </div>

          {/* Column 2: iOS install instructions */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-1.5 font-sans">
            <span className="text-[10px] font-mono text-sky-400 block tracking-wider uppercase font-bold">🍎 2. iPhone / iOS Home Installation</span>
            <p className="text-white/80 text-[11px] leading-relaxed">
              Add this app to your iPhone home screen to make it look, launch, and feel exactly like a real native App Store application:
            </p>
            <ol className="text-white/60 text-[10.5px] space-y-1 font-mono list-decimal pl-4 pt-1">
              <li>Open Safari and copy/load the Direct Fullsite Link.</li>
              <li>Tap the <strong className="text-white">Share</strong> button (box with an up arrow) at the bottom.</li>
              <li>Scroll down and tap <strong className="text-white">"Add to Home Screen"</strong>.</li>
              <li>Open it from your app drawer! It launches fullscreen with no browser borders.</li>
            </ol>
          </div>

          {/* Column 3: Android install instructions */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-1.5 font-sans">
            <span className="text-[10px] font-mono text-emerald-400 block tracking-wider uppercase font-bold">🤖 3. Android / Chrome Installation</span>
            <p className="text-white/80 text-[11px] leading-relaxed">
              Pin it to your Android device to run with full hardware speed and dedicated taskbar accessibility:
            </p>
            <ol className="text-white/60 text-[10.5px] space-y-1 font-mono list-decimal pl-4 pt-1">
              <li>Open Google Chrome on your mobile device.</li>
              <li>Go to the Direct Fullsite Link.</li>
              <li>Tap the <strong className="text-white">Three Dots</strong> menu in the upper right.</li>
              <li>Tap <strong className="text-white">"Install App"</strong> or <strong className="text-white">"Add to Home Screen"</strong>.</li>
              <li>A direct launcher shortcut will instantly appear alongside your other tools!</li>
            </ol>
          </div>
        </div>

        {/* Local Developer Setup / Source Code Export Instruction bar */}
        <div className="bg-black/40 border border-white/5 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 font-sans">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-white/50 uppercase font-semibold">💻 RUNNING AND DEVELOPING LOCALLY ON YOUR COMPUTER</span>
            <p className="text-white/80 text-[11px]">
              Want to download the actual raw files on your computer to host it on your own server or modify the code directly?
            </p>
          </div>
          <div className="bg-[#050505] p-2.5 rounded-lg border border-white/10 text-[11px] text-white/70 max-w-md font-mono shrink-0">
            <strong>How to download:</strong> Click on the <strong className="text-[#00FFC2]">Settings (Gear Icon)</strong> or the <strong className="text-[#00FFC2]">Export</strong> option on the top right header menu of Google AI Studio to download it instantly as a ZIP file or push to GitHub!
          </div>
        </div>
      </div>

      {/* Main Column Split */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Left Columns - Live Outbound Client Dispatched Panel */}
        <div className="lg:col-span-3 space-y-6">
          
          <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4">
            <div className="border-b border-white/10 pb-3 flex items-center justify-between">
              <span className="font-semibold text-white text-sm flex items-center space-x-2">
                <Mail className="text-[#00FFC2]" size={16} />
                <span>Live Client Outbox: Launch Real Outbound Pitches</span>
              </span>
              <span className="text-[10px] text-xs font-mono text-[#00FFC2] bg-[#00FFC2]/10 border border-[#00FFC2]/20 px-2 py-0.5 rounded-full uppercase tracking-wider">
                Active Client Acquisition
              </span>
            </div>

            <p className="text-white/60 text-xs leading-relaxed">
              Find real businesses on the web using the **Leads CRM** or **Google Search Generator** tabs, generate their automated audits using Gemini, and select them below. Pressing <strong>"Launch Outreach Email"</strong> will immediately format a professional client-acquisition email and open your native email system with their address preloaded so you can pitch real prospects!
            </p>

            <div className="bg-black/40 border border-white/5 rounded-xl p-4.5 space-y-4.5">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-semibold text-white/50 block">Choose Target Scraped Lead</label>
                  <select
                    className="w-full bg-black border border-white/10 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-[#00FFC2]"
                    value={selectedLeadId}
                    onChange={(e) => setSelectedLeadId(e.target.value)}
                  >
                    <option value="">-- Choose lead --</option>
                    {leads.map((l, i) => (
                      <option key={i} value={l.id}>
                        {l.businessName} ({l.email ? l.email : "No direct email"})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-semibold text-white/50 block">Inbound Reply Signature</label>
                  <input
                    type="email"
                    className="w-full bg-black border border-white/10 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:ring-1 focus:ring-[#00FFC2] focus:outline-none"
                    value={supportEmail}
                    onChange={(e) => setSupportEmail(e.target.value)}
                    placeholder="Your primary email (e.g. name@domain.com)"
                  />
                </div>
              </div>

              {selectedLead ? (
                <div className="space-y-3.5 border-t border-white/10 pt-4.5 animate-fadeIn">
                  <div className="flex flex-wrap justify-between items-center text-xs gap-2">
                    <div>
                      <span className="text-white/50 block text-[10px] uppercase">Corporate Entity</span>
                      <strong className="text-white text-sm font-sans">{selectedLead.businessName}</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-white/50 block text-[10px] uppercase">Contact Persona</span>
                      <span className="text-[#00FFC2] font-mono">{selectedLead.ownerName || "Business Owner"}</span>
                    </div>
                    <div>
                      <span className="text-white/50 block text-[10px] uppercase">Target Website</span>
                      <a 
                        href={`https://${selectedLead.website}`} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="text-white hover:underline flex items-center space-x-1 font-mono text-xs"
                      >
                        <span>{selectedLead.website}</span>
                        <ExternalLink size={10} className="text-[#00FFC2]" />
                      </a>
                    </div>
                    <div className="text-right">
                      <span className="text-white/50 block text-[10px] uppercase">Calculated Opportunity Space</span>
                      <span className="text-amber-400 font-bold">${(selectedLead.audit?.estimatedRevenueLost ?? 125000).toLocaleString()} USD Leaked</span>
                    </div>
                  </div>

                  {/* Mail Body Preview Display box */}
                  <div className="bg-[#050505] border border-white/10 rounded-xl p-4 space-y-2 text-[11px] font-mono text-white/70 leading-relaxed max-h-[220px] overflow-y-auto">
                    <div className="border-b border-white/10 pb-2 mb-2 text-[10px] uppercase tracking-wider text-teal-400 font-bold flex justify-between">
                      <span>OUTBOX EMAIL PREVIEW</span>
                      <span className="text-white/40">Real-Time Pitch Formulated via Gemini</span>
                    </div>
                    <p className="text-white font-bold text-xs font-sans pb-1">Subject: Question regarding delayed response flows on {selectedLead.website}</p>
                    <p className="whitespace-pre-line text-white/80">{`Hi ${selectedLead.ownerName || "there"},

I was looking closely at your operational structure at ${selectedLead.businessName}... [Email text loaded automatically in mail client]`}</p>
                  </div>

                  <div className="flex justify-end pt-2">
                    {selectedLead.email ? (
                      <a
                        href={getMailtoLink()}
                        className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans font-bold text-xs px-5 py-2.5 rounded-xl flex items-center space-x-2 transition cursor-pointer shadow-[0_4px_12px_rgba(0,255,194,0.15)] hover:shadow-[0_4px_15px_rgba(0,255,194,0.25)]"
                      >
                        <Send size={13} className="text-black" />
                        <span>Dispatch Live Cold Pitch Invitation - Open Email App</span>
                      </a>
                    ) : (
                      <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-xs text-rose-400 font-sans w-full text-center">
                        ⚠️ Selected lead does not have a contact email listed (Standard simulated Leads). Go to the <strong>Leads CRM</strong> tab and search for real companies in the Google Search generator to fetch active matching emails!
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-5 text-center text-white/30 text-xs italic">
                  Select a scraped target lead card above to automatically frame an outbound conversion pitch invitation.
                </div>
              )}

            </div>
          </div>

          {/* Setup Live Gateways Form */}
          <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4">
            <div className="border-b border-white/10 pb-3">
              <span className="font-semibold text-white text-sm flex items-center space-x-2">
                <CreditCard className="text-[#00FFC2]" size={16} />
                <span>Production Gateway Integration Dashboard</span>
              </span>
            </div>

            <p className="text-white/60 text-xs leading-relaxed">
              When a client agrees to go ahead, they pay their upfront retainers and setup fees via online accounts. Standard setup involves supplying your real integrations below or connecting them directly into an automation middleware like Zapier or n8n.
            </p>

            <form onSubmit={handleSaveConfigs} className="space-y-4.5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-semibold text-white/50 block">Stripe Publishable Key</label>
                  <input
                    type="text"
                    className="w-full bg-black border border-white/10 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-[#00FFC2]"
                    placeholder="pk_live_..."
                    value={stripePublishable}
                    onChange={(e) => setStripePublishable(e.target.value)}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-semibold text-white/50 block">Stripe Secret Key</label>
                  <input
                    type="password"
                    className="w-full bg-black border border-white/10 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-[#00FFC2]"
                    placeholder="sk_live_..."
                    value={stripeSecret}
                    onChange={(e) => setStripeSecret(e.target.value)}
                  />
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="text-[10px] uppercase font-semibold text-white/50 block">Live Gemini API Key override (Optional for production scale)</label>
                  <input
                    type="text"
                    className="w-full bg-black border border-white/10 rounded-lg px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-[#00FFC2]"
                    placeholder="AI Studio Gemini API Key override for backend"
                    value={apiKeyInput}
                    onChange={(e) => setApiKeyInput(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <div className="text-[10px] text-white/40 font-mono flex items-center space-x-1.5">
                  <Lock size={12} className="text-[#00FFC2]" />
                  <span>Configured keys are saved securely in your web application state context</span>
                </div>
                
                <div className="flex items-center space-x-2.5">
                  {isSaved && (
                    <span className="text-[11px] text-[#00FFC2] font-semibold flex items-center animate-pulse">
                      ✓ Keys updated successfully
                    </span>
                  )}
                  <button
                    type="submit"
                    className="bg-white/10 hover:bg-white/15 border border-white/10 text-white font-sans text-xs font-bold px-4 py-2 rounded-xl cursor-pointer transition"
                  >
                    Save Operational Configurations
                  </button>
                </div>
              </div>
            </form>
          </div>

        </div>

        {/* Right Columns - Educational Blueprint and Banking Node */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Real Google OAuth Gmail Integration status card */}
          <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-3.5">
            <span className="font-semibold text-white text-sm tracking-wide block uppercase text-white/40">
              Google Workspace Connector
            </span>
            
            <div className="bg-black/30 p-4 rounded-xl border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 bg-blue-500/10 text-blue-400 rounded-lg border border-blue-500/20">
                    <Mail size={16} />
                  </div>
                  <div>
                    <span className="text-[10px] text-white/40 block">INTEGRATION STATUS</span>
                    <strong className={`text-xs block font-mono font-bold ${gmailToken ? 'text-[#00FFC2]' : 'text-amber-500'}`}>
                      {gmailToken ? 'CONNECTED' : 'DISCONNECTED'}
                    </strong>
                  </div>
                </div>
                {gmailToken && (
                  <button
                    onClick={onDisconnectGmail}
                    className="text-rose-400 hover:text-rose-300 text-[10px] uppercase font-mono font-bold cursor-pointer"
                  >
                    Disconnect
                  </button>
                )}
              </div>

              {gmailToken ? (
                <div className="border-t border-white/5 pt-3 space-y-2">
                  <div className="flex items-center space-x-2">
                    {gmailProfile?.picture ? (
                      <img src={gmailProfile.picture} alt="Profile" className="w-6 h-6 rounded-full" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-mono text-[10px] font-bold">G</div>
                    )}
                    <div className="truncate text-xs">
                      <p className="text-white font-bold truncate leading-tight">{gmailProfile?.name || "Connected User"}</p>
                      <p className="text-white/40 text-[10px] truncate">{gmailProfile?.email || "active"}</p>
                    </div>
                  </div>
                  <div className="bg-blue-500/5 text-blue-300 p-2 rounded-lg text-[9.5px] leading-relaxed font-mono font-medium border border-blue-500/10">
                    ✓ Read & send email capabilities verified. Outbound cold pitches will be sent live on behalf of {gmailProfile?.email || "this profile"}.
                  </div>
                </div>
              ) : (
                <div className="space-y-3 border-t border-white/5 pt-3">
                  <p className="text-white/50 text-[10px] leading-relaxed font-mono">
                    Connect your real Google / Gmail account to dispatch automated audits, follow-ups, and calendar invitations instantly to high-ticket corporate clients from the outreach dashboard.
                  </p>
                  <button
                    onClick={async () => {
                      try {
                        const result = await signInWithPopup(auth, googleProvider);
                        const credential = GoogleAuthProvider.credentialFromResult(result);
                        const token = credential?.accessToken;
                        if (!token) {
                          throw new Error('No Google access token received');
                        }
                        const profile = {
                          email: result.user.email || undefined,
                          name: result.user.displayName || undefined,
                          picture: result.user.photoURL || undefined
                        };
                        onConnectGmail(token, profile);
                      } catch (err) {
                        console.error('Workspace activation OAuth error:', err);
                      }
                    }}
                    className="w-full bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans text-xs font-bold py-2 rounded-lg cursor-pointer transition text-center flex items-center justify-center space-x-1.5"
                  >
                    <span>Authorize Google Workspace API</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Real Live Bank verification detail card */}
          <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-3.5">
            <span className="font-semibold text-white text-sm tracking-wide block uppercase text-white/40">
              Verified Banking Settling Node
            </span>
            
            <div className="bg-gradient-to-br from-teal-950/40 via-slate-900 to-black p-4 rounded-xl border border-[#00FFC2]/20 space-y-3">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-[#00FFC2]/15 text-[#00FFC2] rounded-lg border border-[#00FFC2]/40">
                  <Building size={16} />
                </div>
                <div>
                  <span className="text-[10px] text-white/40 block">RECEIVING INSTITUTION</span>
                  <strong className="text-white text-xs block font-mono font-bold">CANARA BANK</strong>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono border-t border-white/10 pt-3">
                <div>
                  <span className="text-[10px] text-white/40 block">Account Number</span>
                  <span className="text-white text-[11px] font-bold">1622101026993</span>
                </div>
                <div>
                  <span className="text-[10px] text-white/40 block">IFSC Code</span>
                  <span className="text-white text-[11px] font-bold">CNR0001622</span>
                </div>
                <div className="col-span-2 mt-1 bg-black/40 p-2 rounded-lg text-[10px] text-[#00FFC2] leading-relaxed flex items-center space-x-1.5">
                  <ShieldCheck size={14} className="shrink-0" />
                  <span>Canara Bank node locked as primary payout routing address.</span>
                </div>
              </div>
            </div>

            <p className="text-white/40 text-[10px] leading-relaxed">
              *Disclaimer: In sandbox operations, payouts are simulated and cleared inside the ledger for demonstration purposes. Connecting real dollars requires establishing an active payments account below.
            </p>
          </div>

          {/* Master Agency Operational Blueprint Checklist - How to make real money */}
          <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-4 space-y-3.5 text-xs font-sans">
            <div className="border-b border-white/10 pb-2 flex items-center space-x-1.5">
              <Compass className="text-teal-400" size={14} />
              <span className="font-semibold text-white uppercase text-[10px] tracking-wider text-white/60">
                Blueprint: How to secure Real Dollar Payouts
              </span>
            </div>

            <div className="space-y-4">
              
              <div className="space-y-1">
                <span className="font-bold text-white block">Step 1 — Scrape & Pitch Real Leads</span>
                <p className="text-white/60 leading-relaxed text-[11px]">
                  Use the **Leads CRM** tab, select 'Search Online', and filter luxury realtors, solar firms, or cosmetic dentists. Our custom server scrapes the actual web for active operations. Extract their details, configure an AI conversion audit, and send them the pre-assembled pitch we built above!
                </p>
              </div>

              <div className="space-y-1">
                <span className="font-bold text-white block">Step 2 — Propose Revenue Recovery Contract</span>
                <p className="text-white/60 leading-relaxed text-[11px]">
                  Schedule a call using Cal.com or Calendly. In your presentation, don't sell "AI bots" – frame your work as a **"24/7 Revenue Recovery Infrastructure"**. Show them the estimated lost income calculated in our **AI Audits** section. Use the **Contracts Node** tab to construct a hybrid agreement with an upfront retainer payout.
                </p>
              </div>

              <div className="space-y-1">
                <span className="font-bold text-white block">Step 3 — Establish Real Billing (Stripe / Wise)</span>
                <p className="text-white/60 leading-relaxed text-[11px]">
                  Open a free **Stripe.com** or **Wise.com** account. Wise or Stripe will act as your credit card and international business wire processors. Generate an invoice inside Stripe, input there your **Canara Bank account details** (AccountNumber, IFSC), and email the secure payment link to your new client.
                </p>
              </div>

              <div className="space-y-1">
                <span className="font-bold text-white block">Step 4 — Collect the Retainer & Auto-Withdraw</span>
                <p className="text-white/60 leading-relaxed text-[11px]">
                  Once the client pays via card or wire, Stripe/Wise collects the physical dollars. Stripe Connect automatically converts these international currencies and sweeps the settled funds directly into your **Canara Bank Account** within 24 hours. That is how real agency owners secure B2B cashflow!
                </p>
              </div>

            </div>
          </div>

          {/* Quick FAQ info block */}
          <div className="bg-white/5 border border-white/1.5 p-4 rounded-xl space-y-2.5 text-xs text-white/80">
            <span className="font-bold text-white flex items-center space-x-1 uppercase text-[10px] text-[#00FFC2]">
              <HelpCircle size={14} />
              <span>Common Operational Questions</span>
            </span>
            <div className="space-y-2 font-sans text-white/70 leading-normal text-[11px]">
              <div>
                <strong className="text-white block">Why has my real bank balance not updated?</strong>
                <span>This workspace represents a management platform that *helps you operate* your business. Like Salesforce or any CRM software, it records bookkeeping ledgers, drafts proposals, and qualifies leads, but it is not linked directly to a master banking mint. Real payouts must be processed through your independent bank portal.</span>
              </div>
              <div className="border-t border-white/5 pt-2">
                <strong className="text-white block">Can I send messages to real numbers?</strong>
                <span>Yes! Once you have saved your configurations, you can build real integrations to dispatch live SMS using Twilio, automated calls, or n8n webhooks.</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
