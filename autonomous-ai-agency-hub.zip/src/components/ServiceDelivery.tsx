import React, { useState } from 'react';
import { ProjectTask, Lead } from '../types';
import { CheckSquare, Square, Plus, ShieldCheck, Sparkles, MessageCircle, Send, Cpu, Check, Activity } from 'lucide-react';

interface ServiceDeliveryProps {
  tasks: ProjectTask[];
  closedLeads: Lead[];
  onToggleTask: (taskId: string) => void;
  onAddTask: (task: ProjectTask) => void;
}

export default function ServiceDelivery({ tasks, closedLeads, onToggleTask, onAddTask }: ServiceDeliveryProps) {
  const [selectedProject, setSelectedProject] = useState(closedLeads[0]?.id || 'lead_6');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  
  // Custom chatbot playground interaction
  const [chatbotConversations, setChatbotConversations] = useState<Array<{ sender: string; text: string }>>([
    { sender: 'assistant', text: 'Corporate Systems Online. How can I help pre-qualify your accident eligibility files today?' }
  ]);
  const [userChatInput, setUserChatInput] = useState('');

  const currentProjectLead = closedLeads.find(l => l.id === selectedProject) || closedLeads[0];

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const newTask: ProjectTask = {
      id: "task_" + Date.now(),
      title: newTaskTitle,
      phase: selectedProject,
      completed: false
    };

    onAddTask(newTask);
    setNewTaskTitle('');
  };

  // Chatbot demo response simulation
  const handleSendChatWidgetMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userChatInput.trim()) return;

    const history = [...chatbotConversations, { sender: 'user', text: userChatInput }];
    setChatbotConversations(history);
    setUserChatInput('');

    // Simulate smart pre-qualification logic based on client industry
    setTimeout(() => {
      let botResponse = "Intake received. Our core CRM routers are transferring this query to Charles Sterling's prioritized schedule queue.";
      const textLower = userChatInput.toLowerCase();

      if (currentProjectLead?.industry?.includes('Legal') || currentProjectLead?.industry?.includes('Law')) {
        if (textLower.includes('accident') || textLower.includes('hurt') || textLower.includes('injury') || textLower.includes('claim')) {
          botResponse = "Understood. The accident logic processor flags this as high-intent. Let's schedule a brief 5-minute intake verification. Should I lock in next Thursday?";
        } else {
          botResponse = "Got it. I have safely registered your query details under Sterling CRM logs. A corporate representative will follow up via SMS.";
        }
      } else if (currentProjectLead?.industry?.includes('Solar')) {
        if (textLower.includes('bill') || textLower.includes('cost') || textLower.includes('panels')) {
          botResponse = "Calculation core active. Energy usage logic maps an average 32% utility reduction for your suburb. Let's schedule an engineer roof audit.";
        }
      } else if (currentProjectLead?.industry?.includes('Real Estate')) {
        if (textLower.includes('buy') || textLower.includes('listing') || textLower.includes('house')) {
          botResponse = "Luxury Sifter active. We have 3 premium off-market properties matching matching conditions in your zone. Should I dispatch brochures to your email?";
        }
      }

      setChatbotConversations([...history, { sender: 'assistant', text: botResponse }]);
    }, 1000);
  };

  const projectTasks = tasks.filter(t => t.phase === selectedProject);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Selector banner */}
      <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 font-mono text-xs">
        <div className="flex items-center space-x-2">
          <Cpu className="text-[#00FFC2]" size={18} />
          <span className="text-white font-sans text-sm font-bold uppercase">&bull; Active Service Deliveries (Phase 10):</span>
        </div>

        <div className="flex items-center space-x-2 font-sans">
          <span className="text-white/40 font-mono text-[11px] uppercase">Select closed-won target:</span>
          <select
            className="bg-[#050505] border border-white/10 rounded px-3 py-1.5 font-mono text-xs text-white focus:outline-none focus:border-[#00FFC2]/50 transition-colors"
            value={selectedProject}
            onChange={(e) => setSelectedProject(e.target.value)}
          >
            {closedLeads.map((cl, i) => (
              <option key={i} value={cl.id}>{cl.businessName}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-sans">
        {/* Onboarding & Task manager checklist */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 space-y-4 text-xs font-mono shadow-2xl">
          <div className="border-b border-white/10 pb-3 flex items-center justify-between">
            <span className="font-sans font-semibold text-white/90 text-sm flex items-center space-x-1.5">
              <span>Task Implementation logs</span>
            </span>
            <span className="text-[10px] text-white/50 bg-[#050505] px-2.5 py-0.5 rounded border border-white/10 font-bold font-mono">
              {projectTasks.filter(t => t.completed).length}/{projectTasks.length} Done
            </span>
          </div>

          {/* Quick Task adder */}
          <form onSubmit={handleCreateTask} className="flex space-x-2 bg-[#050505] p-1.5 border border-white/10 rounded-xl">
            <input
              type="text"
              required
              placeholder="Inject custom deployment deliverable..."
              className="flex-1 bg-transparent border-none text-white text-xs px-3 py-1 focus:outline-none focus:ring-0 font-mono"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
            />
            <button
              type="submit"
              className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black font-sans text-xs px-3.5 py-1.5 rounded-lg font-bold transition flex items-center space-x-1 cursor-pointer"
            >
              <Plus size={14} className="text-black" />
              <span>Add</span>
            </button>
          </form>

          {/* Tasks checklist */}
          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {projectTasks.length === 0 ? (
              <div className="py-12 text-center text-white/30 font-sans">
                No custom project tasks logged for this setup. Use field above to append.
              </div>
            ) : (
              projectTasks.map((task) => (
                <div
                  key={task.id}
                  onClick={() => onToggleTask(task.id)}
                  className={`flex items-start space-x-3 p-3 bg-[#050505] border rounded-xl cursor-pointer hover:border-[#00FFC2]/30 transition duration-200 ${
                    task.completed ? 'border-white/5 text-white/30' : 'border-white/10 text-white/80'
                  }`}
                >
                  {task.completed ? (
                    <CheckSquare size={16} className="text-[#00FFC2] shrink-0 mt-0.5" />
                  ) : (
                    <Square size={16} className="text-white/20 shrink-0 mt-0.5" />
                  )}

                  <div className="flex-1">
                    <p className={`text-[11px] leading-relaxed font-sans ${task.completed ? 'line-through text-white/30' : 'font-medium'}`}>
                      {task.title}
                    </p>
                    {task.notes && (
                      <p className="text-[10px] text-white/40 mt-1 font-mono">{task.notes}</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Live Client widget chatbot preview simulation */}
        <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-5 flex flex-col h-[420px] overflow-hidden shadow-2xl">
          <div className="border-b border-white/10 pb-3 flex items-center justify-between font-mono text-xs mb-3">
            <span className="font-sans font-semibold text-white/90 text-sm flex items-center space-x-1.5">
              <MessageCircle className="text-[#00FFC2] shrink-0" size={16} />
              <span>Delivered Chatbot Widget Pre-display</span>
            </span>
            <span className="text-[9px] bg-[#00FFC2]/15 text-[#00FFC2] px-2 py-0.5 rounded uppercase font-bold border border-[#00FFC2]/25">Active Sandbox</span>
          </div>

          {currentProjectLead ? (
            <div className="flex-1 flex flex-col border border-white/10 rounded-xl bg-[#050505] overflow-hidden font-mono text-[11px] leading-relaxed relative">
              {/* Widget corporate header */}
              <div className="bg-gradient-to-r from-neutral-900 to-[#0a0a0a] px-4 py-3 flex items-center justify-between border-b border-white/10">
                <div>
                  <h5 className="text-white font-sans font-bold text-xs">{currentProjectLead.businessName} Assistant</h5>
                  <p className="text-[9px] text-[#00FFC2] uppercase tracking-widest font-bold mt-0.5">24/7 client qualifying flow</p>
                </div>
                <span className="h-2 w-2 rounded-full bg-[#00FFC2] animate-pulse"></span>
              </div>

              {/* Chat track */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chatbotConversations.map((chat, idx) => {
                  const isAssistant = chat.sender === 'assistant';
                  return (
                    <div key={idx} className={`flex ${isAssistant ? 'justify-start' : 'justify-end'}`}>
                      <div className={`p-3 rounded-2xl max-w-[85%] border shadow-sm ${
                        isAssistant 
                          ? 'bg-white/5 border-white/5 text-white/90' 
                          : 'bg-[#00FFC2]/10 border-[#00FFC2]/20 text-[#00FFC2]'
                      }`}>
                        <p className="font-sans text-[11px]">{chat.text}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Suggestions */}
              <div className="p-2 border-t border-white/10 bg-[#0a0a0a]/40 flex flex-wrap gap-1">
                <button
                  type="button"
                  onClick={() => setUserChatInput("I got catastrophically hurt in an auto collision")}
                  className="bg-[#050505] hover:bg-white/5 text-[10px] text-white/50 px-2 py-1 rounded transition border border-white/10 cursor-pointer"
                >
                  🤕 Accident Claim Demo
                </button>
                <button
                  type="button"
                  onClick={() => setUserChatInput("What is my average monthly solar energy payback savings?")}
                  className="bg-[#050505] hover:bg-white/5 text-[10px] text-white/50 px-2 py-1 rounded transition border border-white/10 cursor-pointer"
                >
                  ☀️ Utility Bill Calculator
                </button>
              </div>

              {/* Form Input */}
              <form onSubmit={handleSendChatWidgetMessage} className="p-2 border-t border-white/10 flex items-center space-x-1">
                <input
                  type="text"
                  placeholder="Test client widget questions..."
                  className="flex-1 bg-[#0a0a0a] text-white rounded px-3 py-1.5 focus:outline-none text-[11px] border border-white/10 focus:border-[#00FFC2]/40 transition-colors"
                  value={userChatInput}
                  onChange={(e) => setUserChatInput(e.target.value)}
                />
                <button
                  type="submit"
                  className="bg-[#00FFC2] hover:bg-[#00E5AE] text-black p-1.5 rounded cursor-pointer transition"
                >
                  <Send size={12} className="text-black" />
                </button>
              </form>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center flex-1 text-white/30 font-sans text-center">
              <Activity className="animate-pulse text-[#00FFC2] mb-2" size={24} />
              <p className="text-xs">Establish 'Closed Won' target contracts in the Leads Database CRM to load previews.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
