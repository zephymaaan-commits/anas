import { IndustryOpportunity, Lead, OutboundCampaign, OBDAppointment, FinancialTransaction, ProjectTask } from "./types";

/**
 * Initial Market Research Opportunities (Phase 1)
 */
export const initialOpportunities: IndustryOpportunity[] = [
  {
    industry: "High-Ticket Real Estate Brokerages",
    opportunityScore: 94,
    avgContractValue: 15000,
    estCloseRate: 18,
    demandCategory: "High",
    manualWorkWaste: "Brokers wasting 10h/week scheduling visual tours, manually copy-pasting lead sheet data, and lacking instant followups for weekend inquiries.",
    reasoning: "High commission size justifies substantial setups. Immediate SMS pre-qualification guarantees hot routing, preventing customer drop-offs."
  },
  {
    industry: "Premium Solar & CleanTech Installers",
    opportunityScore: 91,
    avgContractValue: 12000,
    estCloseRate: 14,
    demandCategory: "High",
    manualWorkWaste: "Delayed scheduling of energy audits, manual roof satellite assessment workflows, and non-optimized phone-tag systems.",
    reasoning: "Adding self-qualification forms that calculate estimated utility savings over API drives high conversion rates."
  },
  {
    industry: "Personal Injury & Corporate Law Firms",
    opportunityScore: 88,
    avgContractValue: 18000,
    estCloseRate: 12,
    demandCategory: "High",
    manualWorkWaste: "Intake attorneys manually reviewing standard accident questionnaires, answering repetitive policy FAQs, and slow callback latency.",
    reasoning: "Law firms value quick screening. Deploying instant intake screening bots filters out standard non-viable cases with near-zero latency."
  },
  {
    industry: "Specialized Orthodontic & Aesthetic Dental Clinics",
    opportunityScore: 85,
    avgContractValue: 8000,
    estCloseRate: 20,
    demandCategory: "High",
    manualWorkWaste: "Manual SMS appointment confirmation, no system for off-hours appointment rescheduling, and missed cosmetic questions on social feeds.",
    reasoning: "Automating Instagram/FB comment replies to direct calendar links is highly profitable for cosmetic healthcare."
  },
  {
    industry: "Enterprise SaaS & B2B Software Companies",
    opportunityScore: 82,
    avgContractValue: 9500,
    estCloseRate: 15,
    demandCategory: "Medium",
    manualWorkWaste: "Slow email-match workflows for free tier signups, and manual assignment of hot prospects to SDR pipelines.",
    reasoning: "Standard lead routing can be optimized using automated intent analysis, boosting sales speeds significantly."
  }
];

/**
 * High-Ticket Leads CRM Database (Phase 2)
 */
export const initialLeads: Lead[] = [
  {
    id: "lead_1",
    businessName: "The Agency RE",
    industry: "High-Ticket Real Estate Brokerages",
    ownerName: "Mauricio Umansky",
    email: "mauricio@theagencyre.com",
    phone: "+1 (310) 278-8888",
    website: "theagencyre.com",
    linkedIn: "linkedin.com/company/the-agency-re",
    country: "United States",
    revenueEstimate: "$15.5M / yr",
    employeeCount: 120,
    status: "Lead",
    notes: "High-end luxury real-estate brokerage based in Beverly Hills. Opportunity: deploy instant Google Maps tour scheduler and pre-qualification flows.",
    dealSize: 15000
  },
  {
    id: "lead_2",
    businessName: "SunPower Corp",
    industry: "Premium Solar & CleanTech Installers",
    ownerName: "Peter Faricy",
    email: "p.faricy@sunpower.com",
    phone: "+1 (800) 786-7693",
    website: "sunpower.com",
    linkedIn: "linkedin.com/company/sunpower-corporation",
    country: "Canada",
    revenueEstimate: "$1.8B / yr",
    employeeCount: 4200,
    status: "Audited",
    notes: "Leading physical residential solar installation giant. Focus: integrate instant GIS roof estimation audit bots to qualify digital web inbounds.",
    dealSize: 12000,
    audit: {
      completedAt: "2026-05-30T04:00:00Z",
      scores: {
        websiteSpeed: 52,
        mobileOptimized: 61,
        seoRank: 48,
        leadForms: 42,
        followUpSystems: 31,
        appointmentBooking: 38,
        customerSupport: 25
      },
      estimatedRevenueLost: 125000,
      revenueOpportunity: "Implement a geographic utility quote widget that converts passive mobile page-clicks into scheduled on-site solar inspections instantly.",
      automationOpportunities: [
        "Interactive Utility Bill Bot: Accepts snap uploads of monthly energy invoices and instantly outlines high-value system ROI summaries.",
        "Geomap Lead Sifter: Screens address roof directions automatically using public maps context to confirm suitability before calendar booking.",
        "Auto-reengagement SMS Sequence: Re-pings lost consultation leads left in CRM cold stages for longer than 30 days."
      ],
      personalizedAuditSummary: "Suffer severe conversion leak. Lead forms require extensive fields with zero speed, and follow-up emails are handled randomly during the workweek by sales reps rather than being automated.",
      suggestedStack: ["n8n.io Cloud Platform", "Gemini 3.5 API Middleware", "Apollo.io API Hooks", "GCP Vision API Module"]
    }
  },
  {
    id: "lead_3",
    businessName: "Morgan & Morgan Law",
    industry: "Personal Injury & Corporate Law Firms",
    ownerName: "John Morgan",
    email: "jmorgan@forthepeople.com",
    phone: "+1 (877) 601-5120",
    website: "forthepeople.com",
    linkedIn: "linkedin.com/company/morgan-&-morgan",
    country: "United Kingdom",
    revenueEstimate: "$250.0M / yr",
    employeeCount: 850,
    status: "Contacted",
    notes: "Largest contingency injury firm in the country. High volume of client leads drop off on after-office inquiries. Needs 24/7 AI-powered triage.",
    dealSize: 18000
  },
  {
    id: "lead_4",
    businessName: "ClearChoice Dental Centers",
    industry: "Specialized Orthodontic & Aesthetic Dental Clinics",
    ownerName: "Kevin Mosher",
    email: "contact@clearchoice.com",
    phone: "+1 (888) 656-1212",
    website: "clearchoice.com",
    linkedIn: "linkedin.com/company/clearchoice-dental-implant-centers",
    country: "UAE",
    revenueEstimate: "$14.2M / yr",
    employeeCount: 160,
    status: "Meeting Booked",
    notes: "Aesthetic clear-aligner and implant center franchise. Meeting confirmed on Tuesday. Needs automated clinic booking scheduler for patients.",
    dealSize: 8000,
    audit: {
      completedAt: "2026-05-29T11:00:00Z",
      scores: {
        websiteSpeed: 75,
        mobileOptimized: 58,
        seoRank: 64,
        leadForms: 35,
        followUpSystems: 42,
        appointmentBooking: 29,
        customerSupport: 18
      },
      estimatedRevenueLost: 68000,
      revenueOpportunity: "Unify cosmetic patient screening onto instant multi-lingual chat, taking off-loading work from clinic reception desk lines.",
      automationOpportunities: [
        "Cosmetic Consult Qualification Flow: Multi-lingual qualifying questions that funnel candidates using direct calendar linkages.",
        "No-Show Prevention SMS Loop: Dispatches automated procedure warnings and schedule reminders 24 hours prior to confirm surgery slots.",
        "Post-Visit Review Harvester: Triggers automated follow-up checking satisfaction and linking directly to preferred clinic ratings engines."
      ],
      personalizedAuditSummary: "Excellent desktop interface but terrible mobile structure. Calendar has zero functional availability, requiring phone callback verification which patients routinely ignore.",
      suggestedStack: ["ManyChat Pro", "WhatsApp Business Gateway API", "Cal.com Scheduler Linkages", "Keap CRM Interface"]
    }
  },
  {
    id: "lead_5",
    businessName: "Workato Enterprise Automation",
    industry: "Enterprise SaaS & B2B Software Companies",
    ownerName: "Vijay Tella",
    email: "v.tella@workato.com",
    phone: "+1 (844) 496-7528",
    website: "workato.com",
    linkedIn: "linkedin.com/company/workato",
    country: "Europe",
    revenueEstimate: "$120.0M / yr",
    employeeCount: 920,
    status: "Proposal Sent",
    notes: "Leading integration iPaaS. Retainer proposal under active evaluation to optimize self-serve SDR qualification pipelines.",
    dealSize: 22000
  },
  {
    id: "lead_6",
    businessName: "Slater and Gordon Lawyers",
    industry: "Personal Injury & Corporate Law Firms",
    ownerName: "Nils Alwardt",
    email: "nils.alwardt@slatergordon.co.uk",
    phone: "+44 (0) 330 041 5869",
    website: "slatergordon.co.uk",
    linkedIn: "linkedin.com/company/slater-and-gordon-uk",
    country: "Australia",
    revenueEstimate: "£185M / yr",
    employeeCount: 1400,
    status: "Closed Won",
    notes: "UK national legal brand. Setup invoice cleared. Task list initialized to deploy multi-lingual chat intake qualification bots.",
    dealSize: 9500
  }
];

/**
 * Outbound Campaigns (Phase 5)
 */
export const initialCampaigns: OutboundCampaign[] = [
  {
    id: "camp_1",
    name: "Luxury Realtors Automated Instate Callback - US",
    subject: "Quick logic enquiry regarding Metropolitan Realtors latencies",
    niche: "High-Ticket Real Estate Brokerages",
    totalLeads: 450,
    sent: 412,
    opens: 298,
    replies: 42,
    meetingsBooked: 11,
    status: "Active",
    abTestVersion: "A (Friction-hook template)"
  },
  {
    id: "camp_2",
    name: "Law intake pre-screening automations - UK",
    subject: "Automating accident client triage for Vance legal",
    niche: "Personal Injury & Corporate Law Firms",
    totalLeads: 320,
    sent: 180,
    opens: 112,
    replies: 15,
    meetingsBooked: 4,
    status: "Active",
    abTestVersion: "B (Lost-revenue calculated projection)"
  },
  {
    id: "camp_3",
    name: "Solar energy inspection scheduler conversion - Canada",
    subject: "Increasing calendar density for Vanguard Solar CA",
    niche: "Premium Solar & CleanTech Installers",
    totalLeads: 280,
    sent: 275,
    opens: 198,
    replies: 18,
    meetingsBooked: 6,
    status: "Paused",
    abTestVersion: "A (Loom visual audit)"
  }
];

/**
 * Sync Appointments (Phase 6)
 */
export const initialAppointments: OBDAppointment[] = [
  {
    id: "appt_1",
    leadId: "lead_4",
    leadName: "Dr. Samir Al-Mansoori",
    businessName: "Radiant Dental Aesthetics",
    dateTime: "2026-06-02T14:00:00Z",
    status: "Scheduled",
    summary: "WhatsApp automation precheck and dynamic calendar syncing live demo.",
    googleCalendarSynced: true,
    calComSynced: true
  },
  {
    id: "appt_2",
    leadId: "lead_2",
    leadName: "Elena Rostova",
    businessName: "Vanguard Solar Solutions",
    dateTime: "2026-06-03T10:30:00Z",
    status: "Scheduled",
    summary: "Reviewing utility Snap-bill AI reader quote design proposal.",
    googleCalendarSynced: true,
    calComSynced: false
  },
  {
    id: "appt_3",
    leadId: "lead_6",
    leadName: "Sarah Jenkins",
    businessName: "Pacific Coast Legal",
    dateTime: "2026-05-30T09:00:00Z",
    status: "Completed",
    summary: "Kickoff call. Collected 25% mobilization fee. Deliverables roadmap agreed.",
    googleCalendarSynced: true,
    calComSynced: true
  }
];

/**
 * Financial Cash Flows Tracker (Phase 9)
 */
export const initialTransactions: FinancialTransaction[] = [
  {
    id: "tx_1",
    leadId: "lead_6",
    businessName: "Pacific Coast Legal",
    amount: 2375, // 25% of 9500
    description: "25% Setup Fee Mobilization Milestone",
    method: "Stripe",
    status: "Paid",
    date: "2026-05-30",
    isUpfrontPayment: true
  },
  {
    id: "tx_2",
    leadId: "lead_4",
    businessName: "Radiant Dental Aesthetics",
    amount: 2000, // 25% of 8000
    description: "Upfront Implementation Setup Deposit",
    method: "Wise",
    status: "Pending",
    date: "2026-06-03",
    isUpfrontPayment: true
  },
  {
    id: "tx_3",
    leadId: "lead_5",
    businessName: "Alps MedTech Group",
    amount: 5500,
    description: "Enterprise Setup Package Payment",
    method: "PayPal",
    status: "Pending",
    date: "2026-06-08",
    isUpfrontPayment: true
  },
  {
    id: "tx_4",
    leadId: "lead_6",
    businessName: "Pacific Coast Legal",
    amount: 7125, // Remaining 75%
    description: "Milestone B - Conversational Intake Complete",
    method: "Stripe",
    status: "Pending",
    date: "2026-06-15",
    isUpfrontPayment: false
  }
];

/**
 * Production Delivery Checklists (Phase 10)
 */
export const initialTasks: ProjectTask[] = [
  {
    id: "task_1",
    title: "Configure multi-lingual instant SMS responder middleware using Twilio API & n8n workflow core",
    phase: "lead_6", // Pacific Coast Legal
    completed: true,
    notes: "SMS response speed checked at 32 seconds under simulated weekend entry loads."
  },
  {
    id: "task_2",
    title: "Develop natural language client qualification intent-classifier using Gemini API on backend",
    phase: "lead_6",
    completed: true,
    notes: "Success tracking: Correctly flags 92% of medical-liability questions vs standard billing chat."
  },
  {
    id: "task_3",
    title: "Sync verified intake submissions into legal CRM custom pipeline fields automatically",
    phase: "lead_6",
    completed: false,
    notes: "Awaiting legal assistant API token from Vance."
  },
  {
    id: "task_4",
    title: "Map custom patient clinic booking slots into Cal.com secure scheduling triggers",
    phase: "lead_6",
    completed: false,
    notes: "Cal.com setup integration completed; finalizing patient reminder SMS script draft."
  }
];
