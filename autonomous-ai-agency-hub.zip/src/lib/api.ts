export async function secureFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const sessionToken = localStorage.getItem("axon_session_id");
  let finalInit = init || {};
  
  if (sessionToken && typeof input === 'string' && input.startsWith('/api/')) {
    const headers = new Headers(finalInit.headers);
    headers.set("Authorization", `Bearer ${sessionToken}`);
    headers.set("x-session-id", sessionToken);
    finalInit = { ...finalInit, headers };
  }
  
  return fetch(input, finalInit);
}
