/**
 * Types & Interfaces for the Autonomous AI Agency Hub
 */

export interface Lead {
  id: string;
  businessName: string;
  industry: string;
  ownerName: string;
  email: string;
  phone: string;
  website: string;
  linkedIn: string;
  country: string;
  revenueEstimate: string;
  employeeCount: number;
  status: 'Lead' | 'Audited' | 'Contacted' | 'Meeting Booked' | 'Proposal Sent' | 'Closed Won' | 'Closed Lost';
  audit?: AIAudit;
  outreachSent?: {
    email?: boolean;
    linkedIn?: boolean;
    sentAt?: string;
  };
  notes?: string;
  dealSize?: number;
}

export interface AIAudit {
  completedAt: string;
  scores: {
    websiteSpeed: number; // 0-100
    mobileOptimized: number; // 0-100
    seoRank: number; // 0-100
    leadForms: number; // 0-100
    followUpSystems: number; // 0-100
    appointmentBooking: number; // 0-100
    customerSupport: number; // 0-100
  };
  estimatedRevenueLost: number; // Annually in USD
  revenueOpportunity: string;
  automationOpportunities: string[];
  personalizedAuditSummary: string;
  suggestedStack: string[];
}

export interface IndustryOpportunity {
  industry: string;
  opportunityScore: number; // 0-100
  avgContractValue: number; // USD
  estCloseRate: number; // Percentage
  reasoning: string;
  demandCategory: 'High' | 'Medium' | 'Emerging';
  manualWorkWaste: string;
}

export interface OutboundCampaign {
  id: string;
  name: string;
  subject: string;
  niche: string;
  totalLeads: number;
  sent: number;
  opens: number;
  replies: number;
  meetingsBooked: number;
  status: 'Active' | 'Paused' | 'Draft';
  abTestVersion: string;
}

export interface OBDAppointment {
  id: string;
  leadId: string;
  leadName: string;
  businessName: string;
  dateTime: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled' | 'No Show';
  summary?: string;
  googleCalendarSynced: boolean;
  calComSynced: boolean;
}

export interface CustomOffer {
  leadId: string;
  pricingStructure: 'performance' | 'revshare' | 'hybrid' | 'retainer' | 'setup';
  setupFee?: number;
  monthlyRetainer?: number;
  revSharePercentage?: number;
  customScope: string;
  contractTerms: string;
}

export interface FinancialTransaction {
  id: string;
  leadId: string;
  businessName: string;
  amount: number;
  description: string;
  method: 'Stripe' | 'Wise' | 'PayPal' | 'Google Pay' | 'UPI';
  status: 'Paid' | 'Pending' | 'Overdue';
  date: string;
  isUpfrontPayment: boolean;
}

export interface ProjectTask {
  id: string;
  title: string;
  phase: string;
  completed: boolean;
  notes?: string;
}
